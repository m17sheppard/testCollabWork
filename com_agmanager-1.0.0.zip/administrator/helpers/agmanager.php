<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Agmanager
 * @author     Micah Windle <support@bankert.ca>
 * @copyright  2021 Bankert Marketing Inc. 
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;

/**
 * Agmanager helper.
 *
 * @since  1.6
 */
class AgmanagerHelper
{
	/**
	 * Configure the Linkbar.
	 *
	 * @param   string  $vName  string
	 *
	 * @return void
	 */
	public static function addSubmenu($vName = '')
	{
		JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_CROPPLANS'),
			'index.php?option=com_agmanager&view=cropplans',
			$vName == 'cropplans'
		);

JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_SEEDS'),
			'index.php?option=com_agmanager&view=seeds',
			$vName == 'seeds'
		);

JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_FERTILIZERS'),
			'index.php?option=com_agmanager&view=fertilizers',
			$vName == 'fertilizers'
		);

JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_CHEMICALS'),
			'index.php?option=com_agmanager&view=chemicals',
			$vName == 'chemicals'
		);

JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_SEEDSUPPLIERS'),
			'index.php?option=com_agmanager&view=seedsuppliers',
			$vName == 'seedsuppliers'
		);

JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_LIVESTOCKS'),
			'index.php?option=com_agmanager&view=livestocks',
			$vName == 'livestocks'
		);

JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_OWNEDLANDS'),
			'index.php?option=com_agmanager&view=ownedlands',
			$vName == 'ownedlands'
		);

JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_LEASEDLANDS'),
			'index.php?option=com_agmanager&view=leasedlands',
			$vName == 'leasedlands'
		);

JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_BUILDINGSQUOTAS'),
			'index.php?option=com_agmanager&view=buildingsquotas',
			$vName == 'buildingsquotas'
		);

JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_BINS'),
			'index.php?option=com_agmanager&view=bins',
			$vName == 'bins'
		);

JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_MACHINERYEQUIPMENTS'),
			'index.php?option=com_agmanager&view=machineryequipments',
			$vName == 'machineryequipments'
		);

JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_DEBTS'),
			'index.php?option=com_agmanager&view=debts',
			$vName == 'debts'
		);

JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_FINANCESINFLOWS'),
			'index.php?option=com_agmanager&view=financesinflows',
			$vName == 'financesinflows'
		);

JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_FINANCEOUTFLOWS'),
			'index.php?option=com_agmanager&view=financeoutflows',
			$vName == 'financeoutflows'
		);

JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_FINANCESASSETS'),
			'index.php?option=com_agmanager&view=financesassets',
			$vName == 'financesassets'
		);

JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_ACCOUNTSPAYABLETYPES'),
			'index.php?option=com_agmanager&view=accountspayabletypes',
			$vName == 'accountspayabletypes'
		);

JHtmlSidebar::addEntry(
			Text::_('COM_AGMANAGER_TITLE_PAYMENTPROJECTIONS'),
			'index.php?option=com_agmanager&view=paymentprojections',
			$vName == 'paymentprojections'
		);

	}

	/**
	 * Gets the files attached to an item
	 *
	 * @param   int     $pk     The item's id
	 *
	 * @param   string  $table  The table's name
	 *
	 * @param   string  $field  The field's name
	 *
	 * @return  array  The files
	 */
	public static function getFiles($pk, $table, $field)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);

		$query
			->select($field)
			->from($table)
			->where('id = ' . (int) $pk);

		$db->setQuery($query);

		return explode(',', $db->loadResult());
	}

	/**
	 * Gets a list of the actions that can be performed.
	 *
	 * @return    JObject
	 *
	 * @since    1.6
	 */
	public static function getActions()
	{
		$user   = Factory::getUser();
		$result = new JObject;

		$assetName = 'com_agmanager';

		$actions = array(
			'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
		);

		foreach ($actions as $action)
		{
			$result->set($action, $user->authorise($action, $assetName));
		}

		return $result;
	}
}

