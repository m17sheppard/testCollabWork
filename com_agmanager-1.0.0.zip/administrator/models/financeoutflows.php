<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Agmanager
 * @author     Micah Windle <support@bankert.ca>
 * @copyright  2021 Bankert Marketing Inc. 
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;

use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\Utilities\ArrayHelper;
/**
 * Methods supporting a list of Agmanager records.
 *
 * @since  1.6
 */
class AgmanagerModelFinanceoutflows extends \Joomla\CMS\MVC\Model\ListModel
{
    
        
/**
	* Constructor.
	*
	* @param   array  $config  An optional associative array of configuration settings.
	*
	* @see        JController
	* @since      1.6
	*/
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id', 'a.`id`',
				'ordering', 'a.`ordering`',
				'state', 'a.`state`',
				'created_by', 'a.`created_by`',
				'modified_by', 'a.`modified_by`',
				'grainhay_purchases', 'a.`grainhay_purchases`',
				'commercial_feed_purchases', 'a.`commercial_feed_purchases`',
				'salt', 'a.`salt`',
				'minerals', 'a.`minerals`',
				'vitamins', 'a.`vitamins`',
				'pasture_rent', 'a.`pasture_rent`',
				'containers_twine', 'a.`containers_twine`',
				'breeding_fees', 'a.`breeding_fees`',
				'vet_fees', 'a.`vet_fees`',
				'drugs', 'a.`drugs`',
				'breeding_stock_purchases', 'a.`breeding_stock_purchases`',
				'market_stock_purchases', 'a.`market_stock_purchases`',
				'marketing_charges', 'a.`marketing_charges`',
				'other_livestock_expenses', 'a.`other_livestock_expenses`',
				'seed_purchases', 'a.`seed_purchases`',
				'seed_cleaning', 'a.`seed_cleaning`',
				'seed_treatment', 'a.`seed_treatment`',
				'fertilizer', 'a.`fertilizer`',
				'chemicals', 'a.`chemicals`',
				'hailcrop_insurance', 'a.`hailcrop_insurance`',
				'other_crop_expenses', 'a.`other_crop_expenses`',
				'property_tax', 'a.`property_tax`',
				'capital_land_purchases', 'a.`capital_land_purchases`',
				'new_lease_payments', 'a.`new_lease_payments`',
				'existing_lease_payments', 'a.`existing_lease_payments`',
				'annual_cash_rent_leased_land', 'a.`annual_cash_rent_leased_land`',
				'fuel', 'a.`fuel`',
				'oil', 'a.`oil`',
				'grease', 'a.`grease`',
				'equipment_repair', 'a.`equipment_repair`',
				'shop_supplies', 'a.`shop_supplies`',
				'small_tools', 'a.`small_tools`',
				'building_insurance', 'a.`building_insurance`',
				'building_repairs', 'a.`building_repairs`',
				'fence_repairs', 'a.`fence_repairs`',
				'vehicle_registrationinsurance', 'a.`vehicle_registrationinsurance`',
				'capital_machinesbuildings_purchases', 'a.`capital_machinesbuildings_purchases`',
				'professional_fees', 'a.`professional_fees`',
				'custom_work', 'a.`custom_work`',
				'hydrotelephone', 'a.`hydrotelephone`',
				'hired_labour', 'a.`hired_labour`',
				'office_expenses', 'a.`office_expenses`',
				'other_assetinvestment_purchases', 'a.`other_assetinvestment_purchases`',
				'other_farm_expenses', 'a.`other_farm_expenses`',
				'living_expenses', 'a.`living_expenses`',
				'income_tax', 'a.`income_tax`',
				'life_insurance', 'a.`life_insurance`',
				'cash_withdrawals', 'a.`cash_withdrawals`',
				'accounts_payable', 'a.`accounts_payable`',
				'repayment_cash_advance_principal', 'a.`repayment_cash_advance_principal`',
				'repayment_cash_advance_interest', 'a.`repayment_cash_advance_interest`',
				'arrears_payment', 'a.`arrears_payment`',
				'term_loan_payment_principal', 'a.`term_loan_payment_principal`',
				'term_loan_payment_interest', 'a.`term_loan_payment_interest`',
			);
		}

		parent::__construct($config);
	}

    
        
       /**
        * Checks whether or not a user is manager or super user
        *
        * @return bool
        */
        public function isAdminOrSuperUser()
        {
            try{
                $user = JFactory::getUser();
                return in_array("8", $user->groups) || in_array("7", $user->groups);
            }catch(Exception $exc){
                return false;
            }
        }
    
        
        /**
         * This method revises if the $id of the item belongs to the current user
         * @param   integer     $id     The id of the item
         * @return  boolean             true if the user is the owner of the row, false if not.
         *
         */
        public function userIDItem($id){
            try{
                $user = JFactory::getUser();
                $db    = JFactory::getDbo();

                $query = $db->getQuery(true);
                $query->select("id")
                      ->from($db->quoteName('#__agmanager_finances_outflow'))
                      ->where("id = " . $db->escape($id))
                      ->where("created_by = " . $user->id);

                $db->setQuery($query);

                $results = $db->loadObject();
                if ($results){
                    return true;
                }else{
                    return false;
                }
            }catch(Exception $exc){
                return false;
            }
        }

        
        /**
         * This method to check if there are items created by the current user.
         * @return  boolean             true if the user created one of the item, false if not.
         *
         */
        public function isUserCreatedItem(){
            try{
                $user = JFactory::getUser();
                $db    = JFactory::getDbo();

                $query = $db->getQuery(true);
                $query->select("id")
                      ->from($db->quoteName('#__agmanager_finances_outflow'))
                      ->where("created_by = " . $user->id);

                $db->setQuery($query);

                $results = $db->loadObject();
                if ($results){
                    return true;
                }else{
                    return false;
                }
            }catch(Exception $exc){
                return false;
            }
        }
	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	protected function populateState($ordering = null, $direction = null)
	{
        // List state information.
        parent::populateState('id', 'ASC');

        $context = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
        $this->setState('filter.search', $context);

        JLoader::register('FieldsHelper', JPATH_ADMINISTRATOR . '/components/com_fields/helpers/fields.php');
        // Split context into component and optional section
        $parts = FieldsHelper::extract($context);

        if ($parts)
        {
            $this->setState('filter.component', $parts[0]);
            $this->setState('filter.section', $parts[1]);
        }
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * This is necessary because the model is used by the component and
	 * different modules that might need different sets of data or different
	 * ordering requirements.
	 *
	 * @param   string  $id  A prefix for the store id.
	 *
	 * @return   string A store id.
	 *
	 * @since    1.6
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');

                if(!$id || $this->userIDItem($id) || $this->isAdminOrSuperUser() || $this->isUserCreatedItem()){
                    return parent::getStoreId($id);
                }else{
                               throw new Exception(Text::_("JERROR_ALERTNOAUTHOR"), 401);
                           }
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return   JDatabaseQuery
	 *
	 * @since    1.6
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db    = $this->getDbo();
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select', 'DISTINCT a.*'
			)
		);
		$query->from('`#__agmanager_finances_outflow` AS a');
                
		// Join over the users for the checked out user
		$query->select("uc.name AS uEditor");
		$query->join("LEFT", "#__users AS uc ON uc.id=a.checked_out");
		if(!$this->isAdminOrSuperUser()){
			$query->where("a.created_by = " . JFactory::getUser()->get("id"));
		}

		// Join over the user field 'created_by'
		$query->select('`created_by`.name AS `created_by`');
		$query->join('LEFT', '#__users AS `created_by` ON `created_by`.id = a.`created_by`');

		// Join over the user field 'modified_by'
		$query->select('`modified_by`.name AS `modified_by`');
		$query->join('LEFT', '#__users AS `modified_by` ON `modified_by`.id = a.`modified_by`');
                

		// Filter by published state
		$published = $this->getState('filter.state');

		if (is_numeric($published))
		{
			$query->where('a.state = ' . (int) $published);
		}
		elseif (empty($published))
		{
			$query->where('(a.state IN (0, 1))');
		}

		// Filter by search in title
		$search = $this->getState('filter.search');

		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				
			}
		}
                
		// Add the list ordering clause.
		$orderCol  = $this->state->get('list.ordering', 'id');
		$orderDirn = $this->state->get('list.direction', 'ASC');

		if ($orderCol && $orderDirn)
		{
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

		//XXX_CUSTOM_ORDER_FOR_NESTED

		return $query;
	}

	/**
	 * Get an array of data items
	 *
	 * @return mixed Array of data items on success, false on failure.
	 */
	public function getItems()
	{
		$items = parent::getItems();
                

		return $items;
	}
}
