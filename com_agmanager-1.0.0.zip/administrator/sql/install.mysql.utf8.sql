CREATE TABLE IF NOT EXISTS `#__agmanager_crop_plan` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`ordering` INT(11)  NOT NULL  DEFAULT 0,
`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`location_legal` VARCHAR(255)  NOT NULL  DEFAULT "",
`location_acreage` DOUBLE,
`plan_crop` TEXT NOT NULL ,
`plan_fertilizer` TEXT NOT NULL ,
`plan_chemical` TEXT NOT NULL ,
`cost_seed` INT(10)  NOT NULL  DEFAULT 0,
`cost_fert` INT(10)  NOT NULL  DEFAULT 0,
`cost_chem` INT(10)  NOT NULL  DEFAULT 0,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__agmanager_seed` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`lft` INT(11)  NOT NULL  DEFAULT 0,
`rgt` INT(11)  NOT NULL  DEFAULT 0,
`level` INT(10)  NOT NULL  DEFAULT 0,
`access` TINYINT(3)  NOT NULL  DEFAULT 0,
`path` VARCHAR(255)  NOT NULL  DEFAULT "",
`crop_type` VARCHAR(25)  NOT NULL ,
`crop_cost` FLOAT NOT NULL ,
`crop_per_acre` FLOAT NOT NULL DEFAULT 0,
`crop_quantity` FLOAT NOT NULL DEFAULT 0,
`seed_supplier` VARCHAR(255)  NOT NULL  DEFAULT "",
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__agmanager_fertilizer` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`lft` INT(11)  NOT NULL  DEFAULT 0,
`rgt` INT(11)  NOT NULL  DEFAULT 0,
`level` INT(10)  NOT NULL  DEFAULT 0,
`access` TINYINT(3)  NOT NULL  DEFAULT 0,
`path` VARCHAR(255)  NOT NULL  DEFAULT "",
`fert_type` VARCHAR(25)  NOT NULL ,
`fert_cost` FLOAT NOT NULL ,
`fert_per_acre` FLOAT NOT NULL DEFAULT 0,
`fert_quantity` FLOAT NOT NULL DEFAULT 0,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__agmanager_chemical` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`lft` INT(11)  NOT NULL  DEFAULT 0,
`rgt` INT(11)  NOT NULL  DEFAULT 0,
`level` INT(10)  NOT NULL  DEFAULT 0,
`access` TINYINT(3)  NOT NULL  DEFAULT 0,
`path` VARCHAR(255)  NOT NULL  DEFAULT "",
`chem_type` VARCHAR(25)  NOT NULL ,
`chem_quantity` FLOAT NOT NULL DEFAULT 0,
`chem_cost` FLOAT NOT NULL ,
`chem_per_acre` FLOAT NOT NULL DEFAULT 0,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__agmanager_seedsuppliers` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`ordering` INT(11)  NOT NULL  DEFAULT 0,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`suppliername` VARCHAR(255)  NOT NULL ,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__agmanager_livestock` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`ordering` INT(11)  NOT NULL  DEFAULT 0,
`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`livestock_category` VARCHAR(255)  NOT NULL  DEFAULT "",
`tag_number` VARCHAR(255)  NOT NULL ,
`transin_date` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`transin_mode` VARCHAR(255)  NOT NULL  DEFAULT "Please Choose...",
`transin_weight` SMALLINT(11)  NOT NULL DEFAULT 0,
`transout_mode` VARCHAR(255)  NOT NULL  DEFAULT "",
`transout_date` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`transout_weight` SMALLINT(11)  NOT NULL DEFAULT 0,
`purchase_price` SMALLINT(11)  NOT NULL DEFAULT 0,
`sale_price` SMALLINT(11)  NOT NULL DEFAULT 0,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__agmanager_owned_land` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`ordering` INT(11)  NOT NULL  DEFAULT 0,
`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`legal_description` VARCHAR(255)  NOT NULL ,
`owner` VARCHAR(255)  NOT NULL  DEFAULT "",
`total_acreage` DOUBLE,
`year_acquired` YEAR NOT NULL  DEFAULT "",
`purchase_price` DOUBLE,
`assessed_value` DOUBLE,
`farmq` VARCHAR(255)  NOT NULL  DEFAULT "1",
`cultivated_acreage` DOUBLE,
`market_value` DOUBLE,
`encumbrance` DOUBLE,
`purchases` DOUBLE,
`sales` DOUBLE,
`asset_gainloss` DOUBLE,
`owned_leased` VARCHAR(255)  NOT NULL  DEFAULT "1",
`lease_years_remaining` INT NOT NULL DEFAULT 0,
`lease_expiration` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__agmanager_leased_land` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`ordering` INT(11)  NOT NULL  DEFAULT 0,
`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`farmq_options` VARCHAR(255)  NOT NULL  DEFAULT "",
`legal_description` VARCHAR(255)  NOT NULL  DEFAULT "",
`owner` VARCHAR(255)  NOT NULL  DEFAULT "",
`total_acreage` DOUBLE,
`year_acquired` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`purchase_price` DOUBLE,
`assessed_value` DOUBLE,
`farmq` VARCHAR(255)  NOT NULL  DEFAULT "",
`cultivated_acreage` DOUBLE,
`market_value` DOUBLE,
`encumbrance` DOUBLE,
`purchases` DOUBLE,
`sales` DOUBLE,
`asset_gainloss` DOUBLE,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__agmanager_building_quota` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`ordering` INT(11)  NOT NULL  DEFAULT 0,
`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`name` VARCHAR(255)  NOT NULL  DEFAULT "",
`construction_date` DATE NOT NULL  DEFAULT "0000",
`location` VARCHAR(255)  NOT NULL  DEFAULT "",
`assessed_value` INT NOT NULL DEFAULT 0,
`year_acquired` DATE NOT NULL  DEFAULT "0000",
`market_value` INT NOT NULL DEFAULT 0,
`purchases` INT NOT NULL DEFAULT 0,
`sales` INT NOT NULL DEFAULT 0,
`asset_gainloss` INT NOT NULL DEFAULT 0,
`condition` VARCHAR(255)  NOT NULL  DEFAULT "",
`maintenance` VARCHAR(255)  NOT NULL  DEFAULT "",
`comments` TEXT NOT NULL ,
`attachments` TEXT NOT NULL ,
`maintenance_frequency` VARCHAR(255)  NOT NULL  DEFAULT "",
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__agmanager_bins` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`ordering` INT(11)  NOT NULL  DEFAULT 0,
`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`description` VARCHAR(255)  NOT NULL  DEFAULT "",
`construction_date` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`quantity` DOUBLE,
`capacity_per_unit` DOUBLE,
`total_capacity` DOUBLE,
`market_value` DOUBLE,
`purchases` DOUBLE,
`sales` DOUBLE,
`asset_gainloss` DOUBLE,
`condition` VARCHAR(255)  NOT NULL  DEFAULT "",
`maintenance` VARCHAR(255)  NOT NULL  DEFAULT "",
`comments` TEXT NOT NULL ,
`attachments` TEXT NOT NULL ,
`maintenance_frequency` VARCHAR(255)  NOT NULL  DEFAULT "",
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__agmanager_machinery_equipment` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`ordering` INT(11)  NOT NULL  DEFAULT 0,
`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`unit` VARCHAR(255)  NOT NULL  DEFAULT "",
`make` VARCHAR(255)  NOT NULL  DEFAULT "",
`model` VARCHAR(255)  NOT NULL  DEFAULT "",
`manufacture_date` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`purchase_date` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`market_value` DOUBLE,
`purchases` DOUBLE,
`sales` DOUBLE,
`asset_gainloss` DOUBLE,
`condition` VARCHAR(255)  NOT NULL  DEFAULT "",
`maintenance` VARCHAR(255)  NOT NULL  DEFAULT "",
`comments` TEXT NOT NULL ,
`attachments` TEXT NOT NULL ,
`purchase_price` DOUBLE,
`maintenance_frequency` VARCHAR(255)  NOT NULL  DEFAULT "",
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__agmanager_debts` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`ordering` INT(11)  NOT NULL  DEFAULT 0,
`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`type` VARCHAR(255)  NOT NULL ,
`original_date` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`original_amount` DOUBLE,
`principal_loan` DOUBLE,
`years_remaining` DOUBLE,
`annual_rent` DOUBLE,
`accrued_interest` DOUBLE,
`arrears` DOUBLE,
`total_amount_outstanding` DOUBLE,
`payment_date` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`crop_share` VARCHAR(255)  NOT NULL  DEFAULT "",
`lease_terms` TEXT NOT NULL ,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__agmanager_finances_inflow` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`ordering` INT(11)  NOT NULL  DEFAULT 0,
`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`custom_work` VARCHAR(255)  NOT NULL  DEFAULT "",
`accounts_receivable` VARCHAR(255)  NOT NULL  DEFAULT "",
`other_farm_income` VARCHAR(255)  NOT NULL  DEFAULT "",
`new_cash_advance` VARCHAR(255)  NOT NULL  DEFAULT "",
`new_term_borrowings` VARCHAR(255)  NOT NULL  DEFAULT "",
`other_asset_sales` VARCHAR(255)  NOT NULL  DEFAULT "",
`off_farm_income` VARCHAR(255)  NOT NULL  DEFAULT "",
`cash_contributions` VARCHAR(255)  NOT NULL  DEFAULT "",
`crop_sales` INT NOT NULL DEFAULT 0,
`breedinglivestocksales` INT NOT NULL DEFAULT 0,
`market_livestock_sales` INT NOT NULL DEFAULT 0,
`livestock_products` INT NOT NULL DEFAULT 0,
`capital_land_sales` INT NOT NULL DEFAULT 0,
`capital_machinebuilding_sales` INT NOT NULL DEFAULT 0,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__agmanager_finances_outflow` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`ordering` INT(11)  NOT NULL  DEFAULT 0,
`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`grainhay_purchases` INT NOT NULL DEFAULT 0,
`commercial_feed_purchases` INT NOT NULL DEFAULT 0,
`salt` INT NOT NULL DEFAULT 0,
`minerals` INT NOT NULL DEFAULT 0,
`vitamins` INT NOT NULL DEFAULT 0,
`pasture_rent` INT NOT NULL DEFAULT 0,
`containers_twine` INT NOT NULL DEFAULT 0,
`breeding_fees` INT NOT NULL DEFAULT 0,
`vet_fees` INT NOT NULL DEFAULT 0,
`drugs` INT NOT NULL DEFAULT 0,
`breeding_stock_purchases` INT NOT NULL DEFAULT 0,
`market_stock_purchases` INT NOT NULL DEFAULT 0,
`marketing_charges` INT NOT NULL DEFAULT 0,
`other_livestock_expenses` INT NOT NULL DEFAULT 0,
`seed_purchases` INT NOT NULL DEFAULT 0,
`seed_cleaning` INT NOT NULL DEFAULT 0,
`seed_treatment` INT NOT NULL DEFAULT 0,
`fertilizer` INT NOT NULL DEFAULT 0,
`chemicals` INT NOT NULL DEFAULT 0,
`hailcrop_insurance` INT NOT NULL DEFAULT 0,
`other_crop_expenses` INT NOT NULL DEFAULT 0,
`property_tax` INT NOT NULL DEFAULT 0,
`capital_land_purchases` INT NOT NULL DEFAULT 0,
`new_lease_payments` INT NOT NULL DEFAULT 0,
`existing_lease_payments` INT NOT NULL DEFAULT 0,
`annual_cash_rent_leased_land` INT NOT NULL DEFAULT 0,
`fuel` INT NOT NULL DEFAULT 0,
`oil` INT NOT NULL DEFAULT 0,
`grease` INT NOT NULL DEFAULT 0,
`equipment_repair` INT NOT NULL DEFAULT 0,
`shop_supplies` INT NOT NULL DEFAULT 0,
`small_tools` INT NOT NULL DEFAULT 0,
`building_insurance` INT NOT NULL DEFAULT 0,
`building_repairs` INT NOT NULL DEFAULT 0,
`fence_repairs` INT NOT NULL DEFAULT 0,
`vehicle_registrationinsurance` INT NOT NULL DEFAULT 0,
`capital_machinesbuildings_purchases` INT NOT NULL DEFAULT 0,
`professional_fees` INT NOT NULL DEFAULT 0,
`custom_work` INT NOT NULL DEFAULT 0,
`hydrotelephone` INT NOT NULL DEFAULT 0,
`hired_labour` INT NOT NULL DEFAULT 0,
`office_expenses` INT NOT NULL DEFAULT 0,
`other_assetinvestment_purchases` INT NOT NULL DEFAULT 0,
`other_farm_expenses` INT NOT NULL DEFAULT 0,
`living_expenses` INT NOT NULL DEFAULT 0,
`income_tax` INT NOT NULL DEFAULT 0,
`life_insurance` INT NOT NULL DEFAULT 0,
`cash_withdrawals` INT NOT NULL DEFAULT 0,
`accounts_payable` INT NOT NULL DEFAULT 0,
`repayment_cash_advance_principal` INT NOT NULL DEFAULT 0,
`repayment_cash_advance_interest` INT NOT NULL DEFAULT 0,
`arrears_payment` INT NOT NULL DEFAULT 0,
`term_loan_payment_principal` INT NOT NULL DEFAULT 0,
`term_loan_payment_interest` INT NOT NULL DEFAULT 0,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__agmanager_finances_assets` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`ordering` INT(11)  NOT NULL  DEFAULT 0,
`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`cash_on_hand` DOUBLE,
`accounts_receivable` DOUBLE,
`market_livestock` DOUBLE,
`grain` DOUBLE,
`farm_supplies` DOUBLE,
`investment_growing_crops` DOUBLE,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__agmanager_accounts_payable_types` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`ordering` INT(11)  NOT NULL  DEFAULT 0,
`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`account_type` VARCHAR(255)  NOT NULL ,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__agmanager_payments_projection` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`ordering` INT(11)  NOT NULL  DEFAULT 0,
`state` TINYINT(1)  NOT NULL  DEFAULT 1,
`checked_out` INT(11)  NOT NULL  DEFAULT 0,
`checked_out_time` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`created_by` INT(11)  NOT NULL  DEFAULT 0,
`modified_by` INT(11)  NOT NULL  DEFAULT 0,
`annual_interest_payment` DOUBLE,
`first_interest_duedate` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`principal_payment_increment` DOUBLE,
`first_principle_due` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`annual_arrears_payment` DOUBLE,
`final_interest_date` DATETIME NOT NULL  DEFAULT "0000-00-00 00:00:00",
`projected_interest_yearend` DOUBLE,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

