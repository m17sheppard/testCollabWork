DROP TABLE IF EXISTS `#__agmanager_crop_plan`;
DROP TABLE IF EXISTS `#__agmanager_seed`;
DROP TABLE IF EXISTS `#__agmanager_fertilizer`;
DROP TABLE IF EXISTS `#__agmanager_chemical`;
DROP TABLE IF EXISTS `#__agmanager_seedsuppliers`;
DROP TABLE IF EXISTS `#__agmanager_livestock`;
DROP TABLE IF EXISTS `#__agmanager_owned_land`;
DROP TABLE IF EXISTS `#__agmanager_leased_land`;
DROP TABLE IF EXISTS `#__agmanager_building_quota`;
DROP TABLE IF EXISTS `#__agmanager_bins`;
DROP TABLE IF EXISTS `#__agmanager_machinery_equipment`;
DROP TABLE IF EXISTS `#__agmanager_debts`;
DROP TABLE IF EXISTS `#__agmanager_finances_inflow`;
DROP TABLE IF EXISTS `#__agmanager_finances_outflow`;
DROP TABLE IF EXISTS `#__agmanager_finances_assets`;
DROP TABLE IF EXISTS `#__agmanager_accounts_payable_types`;
DROP TABLE IF EXISTS `#__agmanager_payments_projection`;

DELETE FROM `#__content_types` WHERE (type_alias LIKE 'com_agmanager.%');