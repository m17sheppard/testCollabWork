<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Agmanager
 * @author     Micah Windle <support@bankert.ca>
 * @copyright  2021 Bankert Marketing Inc. 
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\Utilities\ArrayHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Access\Access;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Table\Table as Table;

/**
 * buildingquota Table class
 *
 * @since  1.6
 */
class AgmanagerTablebuildingquota extends Table
{
	
	/**
	 * Constructor
	 *
	 * @param   JDatabase  &$db  A database connector object
	 */
	public function __construct(&$db)
	{
		parent::__construct('#__agmanager_building_quota', 'id', $db);
		
		
		$this->setColumnAlias('published', 'state');
		
	}

	/**
	 * Overloaded bind function to pre-process the params.
	 *
	 * @param   array  $array   Named array
	 * @param   mixed  $ignore  Optional array or list of parameters to ignore
	 *
	 * @return  null|string  null is operation was satisfactory, otherwise returns an error
	 *
	 * @see     JTable:bind
	 * @since   1.5
     * @throws Exception
	 */
	public function bind($array, $ignore = '')
	{
	    $date = Factory::getDate();
		$task = Factory::getApplication()->input->get('task');
	    
		$input = JFactory::getApplication()->input;
		$task = $input->getString('task', '');

		if ($array['id'] == 0 && empty($array['created_by']))
		{
			$array['created_by'] = JFactory::getUser()->id;
		}

		if ($array['id'] == 0 && empty($array['modified_by']))
		{
			$array['modified_by'] = JFactory::getUser()->id;
		}

		if ($task == 'apply' || $task == 'save')
		{
			$array['modified_by'] = JFactory::getUser()->id;
		}

		// Support for multiple field: condition
		if (isset($array['condition']))
		{
			if (is_array($array['condition']))
			{
				$array['condition'] = implode(',',$array['condition']);
			}
			elseif (strpos($array['condition'], ',') != false)
			{
				$array['condition'] = explode(',',$array['condition']);
			}
			elseif (strlen($array['condition']) == 0)
			{
				$array['condition'] = '';
			}
		}
		else
		{
			$array['condition'] = '';
		}

		// Support for multiple field: maintenance
		if (isset($array['maintenance']))
		{
			if (is_array($array['maintenance']))
			{
				$array['maintenance'] = implode(',',$array['maintenance']);
			}
			elseif (strpos($array['maintenance'], ',') != false)
			{
				$array['maintenance'] = explode(',',$array['maintenance']);
			}
			elseif (strlen($array['maintenance']) == 0)
			{
				$array['maintenance'] = '';
			}
		}
		else
		{
			$array['maintenance'] = '';
		}
		// Support for multi file field: attachments
		if (!empty($array['attachments']))
		{
			if (is_array($array['attachments']))
			{
				$array['attachments'] = implode(',', $array['attachments']);
			}
			elseif (strpos($array['attachments'], ',') != false)
			{
				$array['attachments'] = explode(',', $array['attachments']);
			}
		}
		else
		{
			$array['attachments'] = '';
		}


		// Support for multiple field: maintenance_frequency
		if (isset($array['maintenance_frequency']))
		{
			if (is_array($array['maintenance_frequency']))
			{
				$array['maintenance_frequency'] = implode(',',$array['maintenance_frequency']);
			}
			elseif (strpos($array['maintenance_frequency'], ',') != false)
			{
				$array['maintenance_frequency'] = explode(',',$array['maintenance_frequency']);
			}
			elseif (strlen($array['maintenance_frequency']) == 0)
			{
				$array['maintenance_frequency'] = '';
			}
		}
		else
		{
			$array['maintenance_frequency'] = '';
		}

		if (isset($array['params']) && is_array($array['params']))
		{
			$registry = new JRegistry;
			$registry->loadArray($array['params']);
			$array['params'] = (string) $registry;
		}

		if (isset($array['metadata']) && is_array($array['metadata']))
		{
			$registry = new JRegistry;
			$registry->loadArray($array['metadata']);
			$array['metadata'] = (string) $registry;
		}

		if (!Factory::getUser()->authorise('core.admin', 'com_agmanager.buildingquota.' . $array['id']))
		{
			$actions         = Access::getActionsFromFile(
				JPATH_ADMINISTRATOR . '/components/com_agmanager/access.xml',
				"/access/section[@name='buildingquota']/"
			);
			$default_actions = Access::getAssetRules('com_agmanager.buildingquota.' . $array['id'])->getData();
			$array_jaccess   = array();

			foreach ($actions as $action)
			{
                if (key_exists($action->name, $default_actions))
                {
                    $array_jaccess[$action->name] = $default_actions[$action->name];
                }
			}

			$array['rules'] = $this->JAccessRulestoArray($array_jaccess);
		}

		// Bind the rules for ACL where supported.
		if (isset($array['rules']) && is_array($array['rules']))
		{
			$this->setRules($array['rules']);
		}

		return parent::bind($array, $ignore);
	}

	/**
	 * This function convert an array of JAccessRule objects into an rules array.
	 *
	 * @param   array  $jaccessrules  An array of JAccessRule objects.
	 *
	 * @return  array
	 */
	private function JAccessRulestoArray($jaccessrules)
	{
		$rules = array();

		foreach ($jaccessrules as $action => $jaccess)
		{
			$actions = array();

			if ($jaccess)
			{
				foreach ($jaccess->getData() as $group => $allow)
				{
					$actions[$group] = ((bool)$allow);
				}
			}

			$rules[$action] = $actions;
		}

		return $rules;
	}

	/**
	 * Overloaded check function
	 *
	 * @return bool
	 */
	public function check()
	{
		// If there is an ordering column and this is a new row then get the next ordering value
		if (property_exists($this, 'ordering') && $this->id == 0)
		{
			$this->ordering = self::getNextOrder();
		}
		
		
		// Support multi file field: attachments
		$app = JFactory::getApplication();
		$files = $app->input->files->get('jform', array(), 'raw');
		$array = $app->input->get('jform', array(), 'ARRAY');

		if ($files['attachments'][0]['size'] > 0)
		{
			// Deleting existing files
			$oldFiles = AgmanagerHelper::getFiles($this->id, $this->_tbl, 'attachments');

			foreach ($oldFiles as $f)
			{
				$oldFile = JPATH_ROOT . '/uploads/' . $f;

				if (file_exists($oldFile) && !is_dir($oldFile))
				{
					unlink($oldFile);
				}
			}

			$this->attachments = "";

			foreach ($files['attachments'] as $singleFile )
			{
				jimport('joomla.filesystem.file');

				// Check if the server found any error.
				$fileError = $singleFile['error'];
				$message = '';

				if ($fileError > 0 && $fileError != 4)
				{
					switch ($fileError)
					{
						case 1:
							$message = JText::_('File size exceeds allowed by the server');
							break;
						case 2:
							$message = JText::_('File size exceeds allowed by the html form');
							break;
						case 3:
							$message = JText::_('Partial upload error');
							break;
					}

					if ($message != '')
					{
						$app->enqueueMessage($message, 'warning');

						return false;
					}
				}
				elseif ($fileError == 4)
				{
					if (isset($array['attachments']))
					{
						$this->attachments = $array['attachments'];
					}
				}
				else
				{

					// Replace any special characters in the filename
					jimport('joomla.filesystem.file');
					$filename = JFile::stripExt($singleFile['name']);
					$extension = JFile::getExt($singleFile['name']);
					$filename = preg_replace("/[^A-Za-z0-9]/i", "-", $filename);
					$filename = $filename . '.' . $extension;
					$uploadPath = JPATH_ROOT . '/uploads/' . $filename;
					$fileTemp = $singleFile['tmp_name'];

					if (!JFile::exists($uploadPath))
					{
						if (!JFile::upload($fileTemp, $uploadPath))
						{
							$app->enqueueMessage('Error moving file', 'warning');

							return false;
						}
					}

					$this->attachments .= (!empty($this->attachments)) ? "," : "";
					$this->attachments .= $filename;
				}
			}
		}
		else
		{
			$this->attachments .= $array['attachments_hidden'];
		}

		return parent::check();
	}

	/**
	 * Define a namespaced asset name for inclusion in the #__assets table
	 *
	 * @return string The asset name
	 *
	 * @see Table::_getAssetName
	 */
	protected function _getAssetName()
	{
		$k = $this->_tbl_key;

		return 'com_agmanager.buildingquota.' . (int) $this->$k;
	}

	/**
	 * Returns the parent asset's id. If you have a tree structure, retrieve the parent's id using the external key field
	 *
	 * @param   JTable   $table  Table name
	 * @param   integer  $id     Id
	 *
	 * @see Table::_getAssetParentId
	 *
	 * @return mixed The id on success, false on failure.
	 */
	protected function _getAssetParentId(JTable $table = null, $id = null)
	{
		// We will retrieve the parent-asset from the Asset-table
		$assetParent = Table::getInstance('Asset');

		// Default: if no asset-parent can be found we take the global asset
		$assetParentId = $assetParent->getRootId();

		// The item has the component as asset-parent
		$assetParent->loadByName('com_agmanager');

		// Return the found asset-parent-id
		if ($assetParent->id)
		{
			$assetParentId = $assetParent->id;
		}

		return $assetParentId;
	}

	
    /**
     * Delete a record by id
     *
     * @param   mixed  $pk  Primary key value to delete. Optional
     *
     * @return bool
     */
    public function delete($pk = null)
    {
        $this->load($pk);
        $result = parent::delete($pk);
        
		if ($result)
		{
			jimport('joomla.filesystem.file');

			$checkImageVariableType = gettype($this->attachments);

			switch ($checkImageVariableType)
			{
			case 'string':
				JFile::delete(JPATH_ROOT . '/uploads/' . $this->attachments);
			break;
			default:
			foreach ($this->attachments as $attachmentsFile)
			{
				JFile::delete(JPATH_ROOT . '/uploads/' . $attachmentsFile);
			}
			}
		}

        return $result;
    }

	

	
}
