<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Agmanager
 * @author     Micah Windle <support@bankert.ca>
 * @copyright  2021 Bankert Marketing Inc. 
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\Utilities\ArrayHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Access\Access;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Table\Table as Table;

/**
 * cropplan Table class
 *
 * @since  1.6
 */
class AgmanagerTablecropplan extends Table
{
	
	/**
	 * Constructor
	 *
	 * @param   JDatabase  &$db  A database connector object
	 */
	public function __construct(&$db)
	{
		parent::__construct('#__agmanager_crop_plan', 'id', $db);
		
		
		$this->setColumnAlias('published', 'state');
		
	}

	/**
	 * Overloaded bind function to pre-process the params.
	 *
	 * @param   array  $array   Named array
	 * @param   mixed  $ignore  Optional array or list of parameters to ignore
	 *
	 * @return  null|string  null is operation was satisfactory, otherwise returns an error
	 *
	 * @see     JTable:bind
	 * @since   1.5
     * @throws Exception
	 */
	public function bind($array, $ignore = '')
	{
	    $date = Factory::getDate();
		$task = Factory::getApplication()->input->get('task');
	    
		$input = JFactory::getApplication()->input;
		$task = $input->getString('task', '');

		if ($array['id'] == 0 && empty($array['created_by']))
		{
			$array['created_by'] = JFactory::getUser()->id;
		}

		if ($array['id'] == 0 && empty($array['modified_by']))
		{
			$array['modified_by'] = JFactory::getUser()->id;
		}

		if ($task == 'apply' || $task == 'save')
		{
			$array['modified_by'] = JFactory::getUser()->id;
		}

		// Support for multiple or not foreign key field: plan_crop
			if(!empty($array['plan_crop']))
			{
				if(is_array($array['plan_crop'])){
					$array['plan_crop'] = implode(',',$array['plan_crop']);
				}
				else if(strrpos($array['plan_crop'], ',') != false){
					$array['plan_crop'] = explode(',',$array['plan_crop']);
				}
			}
			else {
				$array['plan_crop'] = 0;
			}

		// Support for multiple or not foreign key field: plan_fertilizer
			if(!empty($array['plan_fertilizer']))
			{
				if(is_array($array['plan_fertilizer'])){
					$array['plan_fertilizer'] = implode(',',$array['plan_fertilizer']);
				}
				else if(strrpos($array['plan_fertilizer'], ',') != false){
					$array['plan_fertilizer'] = explode(',',$array['plan_fertilizer']);
				}
			}
			else {
				$array['plan_fertilizer'] = 0;
			}

		// Support for multiple or not foreign key field: plan_chemical
			if(!empty($array['plan_chemical']))
			{
				if(is_array($array['plan_chemical'])){
					$array['plan_chemical'] = implode(',',$array['plan_chemical']);
				}
				else if(strrpos($array['plan_chemical'], ',') != false){
					$array['plan_chemical'] = explode(',',$array['plan_chemical']);
				}
			}
			else {
				$array['plan_chemical'] = 0;
			}

		// Support for multiple or not foreign key field: cost_seed
			if(!empty($array['cost_seed']))
			{
				if(is_array($array['cost_seed'])){
					$array['cost_seed'] = implode(',',$array['cost_seed']);
				}
				else if(strrpos($array['cost_seed'], ',') != false){
					$array['cost_seed'] = explode(',',$array['cost_seed']);
				}
			}
			else {
				$array['cost_seed'] = 0;
			}

		// Support for multiple or not foreign key field: cost_fert
			if(!empty($array['cost_fert']))
			{
				if(is_array($array['cost_fert'])){
					$array['cost_fert'] = implode(',',$array['cost_fert']);
				}
				else if(strrpos($array['cost_fert'], ',') != false){
					$array['cost_fert'] = explode(',',$array['cost_fert']);
				}
			}
			else {
				$array['cost_fert'] = 0;
			}

		// Support for multiple or not foreign key field: cost_chem
			if(!empty($array['cost_chem']))
			{
				if(is_array($array['cost_chem'])){
					$array['cost_chem'] = implode(',',$array['cost_chem']);
				}
				else if(strrpos($array['cost_chem'], ',') != false){
					$array['cost_chem'] = explode(',',$array['cost_chem']);
				}
			}
			else {
				$array['cost_chem'] = 0;
			}

		if (isset($array['params']) && is_array($array['params']))
		{
			$registry = new JRegistry;
			$registry->loadArray($array['params']);
			$array['params'] = (string) $registry;
		}

		if (isset($array['metadata']) && is_array($array['metadata']))
		{
			$registry = new JRegistry;
			$registry->loadArray($array['metadata']);
			$array['metadata'] = (string) $registry;
		}

		if (!Factory::getUser()->authorise('core.admin', 'com_agmanager.cropplan.' . $array['id']))
		{
			$actions         = Access::getActionsFromFile(
				JPATH_ADMINISTRATOR . '/components/com_agmanager/access.xml',
				"/access/section[@name='cropplan']/"
			);
			$default_actions = Access::getAssetRules('com_agmanager.cropplan.' . $array['id'])->getData();
			$array_jaccess   = array();

			foreach ($actions as $action)
			{
                if (key_exists($action->name, $default_actions))
                {
                    $array_jaccess[$action->name] = $default_actions[$action->name];
                }
			}

			$array['rules'] = $this->JAccessRulestoArray($array_jaccess);
		}

		// Bind the rules for ACL where supported.
		if (isset($array['rules']) && is_array($array['rules']))
		{
			$this->setRules($array['rules']);
		}

		return parent::bind($array, $ignore);
	}

	/**
	 * This function convert an array of JAccessRule objects into an rules array.
	 *
	 * @param   array  $jaccessrules  An array of JAccessRule objects.
	 *
	 * @return  array
	 */
	private function JAccessRulestoArray($jaccessrules)
	{
		$rules = array();

		foreach ($jaccessrules as $action => $jaccess)
		{
			$actions = array();

			if ($jaccess)
			{
				foreach ($jaccess->getData() as $group => $allow)
				{
					$actions[$group] = ((bool)$allow);
				}
			}

			$rules[$action] = $actions;
		}

		return $rules;
	}

	/**
	 * Overloaded check function
	 *
	 * @return bool
	 */
	public function check()
	{
		// If there is an ordering column and this is a new row then get the next ordering value
		if (property_exists($this, 'ordering') && $this->id == 0)
		{
			$this->ordering = self::getNextOrder();
		}
		
		

		return parent::check();
	}

	/**
	 * Define a namespaced asset name for inclusion in the #__assets table
	 *
	 * @return string The asset name
	 *
	 * @see Table::_getAssetName
	 */
	protected function _getAssetName()
	{
		$k = $this->_tbl_key;

		return 'com_agmanager.cropplan.' . (int) $this->$k;
	}

	/**
	 * Returns the parent asset's id. If you have a tree structure, retrieve the parent's id using the external key field
	 *
	 * @param   JTable   $table  Table name
	 * @param   integer  $id     Id
	 *
	 * @see Table::_getAssetParentId
	 *
	 * @return mixed The id on success, false on failure.
	 */
	protected function _getAssetParentId(JTable $table = null, $id = null)
	{
		// We will retrieve the parent-asset from the Asset-table
		$assetParent = Table::getInstance('Asset');

		// Default: if no asset-parent can be found we take the global asset
		$assetParentId = $assetParent->getRootId();

		// The item has the component as asset-parent
		$assetParent->loadByName('com_agmanager');

		// Return the found asset-parent-id
		if ($assetParent->id)
		{
			$assetParentId = $assetParent->id;
		}

		return $assetParentId;
	}

	
    /**
     * Delete a record by id
     *
     * @param   mixed  $pk  Primary key value to delete. Optional
     *
     * @return bool
     */
    public function delete($pk = null)
    {
        $this->load($pk);
        $result = parent::delete($pk);
        
        return $result;
    }

	

	
}
