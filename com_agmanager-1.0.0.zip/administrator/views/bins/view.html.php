<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Agmanager
 * @author     Micah Windle <support@bankert.ca>
 * @copyright  2021 Bankert Marketing Inc. 
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

use \Joomla\CMS\Language\Text;

/**
 * View class for a list of Agmanager.
 *
 * @since  1.6
 */
class AgmanagerViewBins extends \Joomla\CMS\MVC\View\HtmlView
{
	protected $items;

	protected $pagination;

	protected $state;

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  Template name
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	public function display($tpl = null)
	{
		$this->state = $this->get('State');
		$this->items = $this->get('Items');
		$this->pagination = $this->get('Pagination');
        $this->filterForm = $this->get('FilterForm');
        $this->activeFilters = $this->get('ActiveFilters');

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new Exception(implode("\n", $errors));
		}

		AgmanagerHelper::addSubmenu('bins');

		$this->addToolbar();

		$this->sidebar = JHtmlSidebar::render();
		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return void
	 *
	 * @since    1.6
	 */
	protected function addToolbar()
	{
		$state = $this->get('State');
		$canDo = AgmanagerHelper::getActions();

		JToolBarHelper::title(Text::_('COM_AGMANAGER_TITLE_BINS'), 'bins.png');

		// Check if the form exists before showing the add/edit buttons
		$formPath = JPATH_COMPONENT_ADMINISTRATOR . '/views/bin';

		if (file_exists($formPath))
		{
			if ($canDo->get('core.create'))
			{
				JToolBarHelper::addNew('bin.add', 'JTOOLBAR_NEW');

				if (isset($this->items[0]))
				{
					JToolbarHelper::custom('bins.duplicate', 'copy.png', 'copy_f2.png', 'JTOOLBAR_DUPLICATE', true);
				}
			}

			if ($canDo->get('core.edit') && isset($this->items[0]))
			{
				JToolBarHelper::editList('bin.edit', 'JTOOLBAR_EDIT');
			}
		}

		if ($canDo->get('core.edit.state'))
		{
			if (isset($this->items[0]->state))
			{
				JToolBarHelper::divider();
				JToolBarHelper::custom('bins.publish', 'publish.png', 'publish_f2.png', 'JTOOLBAR_PUBLISH', true);
				JToolBarHelper::custom('bins.unpublish', 'unpublish.png', 'unpublish_f2.png', 'JTOOLBAR_UNPUBLISH', true);
			}
			elseif (isset($this->items[0]))
			{
				// If this component does not use state then show a direct delete button as we can not trash
				JToolBarHelper::deleteList('', 'bins.delete', 'JTOOLBAR_DELETE');
			}

			if (isset($this->items[0]->state))
			{
				JToolBarHelper::divider();
				JToolBarHelper::archiveList('bins.archive', 'JTOOLBAR_ARCHIVE');
			}

			if (isset($this->items[0]->checked_out))
			{
				JToolBarHelper::custom('bins.checkin', 'checkin.png', 'checkin_f2.png', 'JTOOLBAR_CHECKIN', true);
			}
		}

		// Show trash and delete for components that uses the state field
		if (isset($this->items[0]->state))
		{
			if ($state->get('filter.state') == -2 && $canDo->get('core.delete'))
			{
				JToolBarHelper::deleteList('', 'bins.delete', 'JTOOLBAR_EMPTY_TRASH');
				JToolBarHelper::divider();
			}
			elseif ($canDo->get('core.edit.state'))
			{
				JToolBarHelper::trash('bins.trash', 'JTOOLBAR_TRASH');
				JToolBarHelper::divider();
			}
		}

		

		if ($canDo->get('core.admin'))
		{
			JToolBarHelper::preferences('com_agmanager');
		}

		// Set sidebar action - New in 3.0
		JHtmlSidebar::setAction('index.php?option=com_agmanager&view=bins');
	}

	/**
	 * Method to order fields 
	 *
	 * @return void 
	 */
	protected function getSortFields()
	{
		return array(
			'a.`description`' => JText::_('COM_AGMANAGER_BINS_DESCRIPTION'),
			'a.`construction_date`' => JText::_('COM_AGMANAGER_BINS_CONSTRUCTION_DATE'),
			'a.`quantity`' => JText::_('COM_AGMANAGER_BINS_QUANTITY'),
			'a.`capacity_per_unit`' => JText::_('COM_AGMANAGER_BINS_CAPACITY_PER_UNIT'),
			'a.`total_capacity`' => JText::_('COM_AGMANAGER_BINS_TOTAL_CAPACITY'),
			'a.`market_value`' => JText::_('COM_AGMANAGER_BINS_MARKET_VALUE'),
			'a.`purchases`' => JText::_('COM_AGMANAGER_BINS_PURCHASES'),
			'a.`sales`' => JText::_('COM_AGMANAGER_BINS_SALES'),
			'a.`asset_gainloss`' => JText::_('COM_AGMANAGER_BINS_ASSET_GAINLOSS'),
			'a.`condition`' => JText::_('COM_AGMANAGER_BINS_CONDITION'),
			'a.`maintenance`' => JText::_('COM_AGMANAGER_BINS_MAINTENANCE'),
			'a.`comments`' => JText::_('COM_AGMANAGER_BINS_COMMENTS'),
			'a.`attachments`' => JText::_('COM_AGMANAGER_BINS_ATTACHMENTS'),
			'a.`maintenance_frequency`' => JText::_('COM_AGMANAGER_BINS_MAINTENANCE_FREQUENCY'),
		);
	}

    /**
     * Check if state is set
     *
     * @param   mixed  $state  State
     *
     * @return bool
     */
    public function getState($state)
    {
        return isset($this->state->{$state}) ? $this->state->{$state} : false;
    }
}
