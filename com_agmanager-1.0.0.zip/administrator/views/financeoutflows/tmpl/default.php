<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Agmanager
 * @author     Micah Windle <support@bankert.ca>
 * @copyright  2021 Bankert Marketing Inc. 
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;


use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Layout\LayoutHelper;
use \Joomla\CMS\Language\Text;

HTMLHelper::addIncludePath(JPATH_COMPONENT . '/helpers/');
HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');
HTMLHelper::_('formbehavior.chosen', 'select');

// Import CSS
$document = Factory::getDocument();
$document->addStyleSheet(Uri::root() . 'administrator/components/com_agmanager/assets/css/agmanager.css');
$document->addStyleSheet(Uri::root() . 'media/com_agmanager/css/list.css');

$user      = Factory::getUser();
$userId    = $user->get('id');
$listOrder = $this->state->get('list.ordering');
$listDirn  = $this->state->get('list.direction');
$canOrder  = $user->authorise('core.edit.state', 'com_agmanager');
$saveOrder = $listOrder == 'a.`ordering`';

if ($saveOrder)
{
	$saveOrderingUrl = 'index.php?option=com_agmanager&task=financeoutflows.saveOrderAjax&tmpl=component';
    HTMLHelper::_('sortablelist.sortable', 'financesoutflowList', 'adminForm', strtolower($listDirn), $saveOrderingUrl);
}

$sortFields = $this->getSortFields();
?>

<form action="<?php echo Route::_('index.php?option=com_agmanager&view=financeoutflows'); ?>" method="post"
	  name="adminForm" id="adminForm">
	<?php if (!empty($this->sidebar)): ?>
	<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
	</div>
	<div id="j-main-container" class="span10">
		<?php else : ?>
		<div id="j-main-container">
			<?php endif; ?>

            <?php echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this)); ?>

			<div class="clearfix"></div>
			<table class="table table-striped" id="financesoutflowList">
				<thead>
				<tr>
					<?php if (isset($this->items[0]->ordering)): ?>
						<th width="1%" class="nowrap center hidden-phone">
                            <?php echo HTMLHelper::_('searchtools.sort', '', 'a.`ordering`', $listDirn, $listOrder, null, 'asc', 'JGRID_HEADING_ORDERING', 'icon-menu-2'); ?>
                        </th>
					<?php endif; ?>
					<th width="1%" >
						<input type="checkbox" name="checkall-toggle" value=""
							   title="<?php echo Text::_('JGLOBAL_CHECK_ALL'); ?>" onclick="Joomla.checkAll(this)"/>
					</th>
					<?php if (isset($this->items[0]->state)): ?>
						
					<?php endif; ?>

									<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_SEED_PURCHASES', 'a.`seed_purchases`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_SEED_CLEANING', 'a.`seed_cleaning`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_SEED_TREATMENT', 'a.`seed_treatment`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_FERTILIZER', 'a.`fertilizer`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_CHEMICALS', 'a.`chemicals`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_HAILCROP_INSURANCE', 'a.`hailcrop_insurance`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_OTHER_CROP_EXPENSES', 'a.`other_crop_expenses`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_GRAINHAY_PURCHASES', 'a.`grainhay_purchases`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_COMMERCIAL_FEED_PURCHASES', 'a.`commercial_feed_purchases`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_SALT', 'a.`salt`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_MINERALS', 'a.`minerals`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_VITAMINS', 'a.`vitamins`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_PASTURE_RENT', 'a.`pasture_rent`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_CONTAINERS_TWINE', 'a.`containers_twine`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_BREEDING_FEES', 'a.`breeding_fees`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_VET_FEES', 'a.`vet_fees`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_DRUGS', 'a.`drugs`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_BREEDING_STOCK_PURCHASES', 'a.`breeding_stock_purchases`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_MARKET_STOCK_PURCHASES', 'a.`market_stock_purchases`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_MARKETING_CHARGES', 'a.`marketing_charges`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_OTHER_LIVESTOCK_EXPENSES', 'a.`other_livestock_expenses`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_PROPERTY_TAX', 'a.`property_tax`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_CAPITAL_LAND_PURCHASES', 'a.`capital_land_purchases`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_NEW_LEASE_PAYMENTS', 'a.`new_lease_payments`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_EXISTING_LEASE_PAYMENTS', 'a.`existing_lease_payments`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_ANNUAL_CASH_RENT_LEASED_LAND', 'a.`annual_cash_rent_leased_land`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_FUEL', 'a.`fuel`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_OIL', 'a.`oil`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_GREASE', 'a.`grease`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_EQUIPMENT_REPAIR', 'a.`equipment_repair`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_SHOP_SUPPLIES', 'a.`shop_supplies`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_SMALL_TOOLS', 'a.`small_tools`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_BUILDING_INSURANCE', 'a.`building_insurance`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_BUILDING_REPAIRS', 'a.`building_repairs`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_FENCE_REPAIRS', 'a.`fence_repairs`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_VEHICLE_REGISTRATIONINSURANCE', 'a.`vehicle_registrationinsurance`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_CAPITAL_MACHINESBUILDINGS_PURCHASES', 'a.`capital_machinesbuildings_purchases`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_PROFESSIONAL_FEES', 'a.`professional_fees`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_CUSTOM_WORK', 'a.`custom_work`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_HYDROTELEPHONE', 'a.`hydrotelephone`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_HIRED_LABOUR', 'a.`hired_labour`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_OFFICE_EXPENSES', 'a.`office_expenses`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_OTHER_ASSETINVESTMENT_PURCHASES', 'a.`other_assetinvestment_purchases`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_OTHER_FARM_EXPENSES', 'a.`other_farm_expenses`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_LIVING_EXPENSES', 'a.`living_expenses`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_INCOME_TAX', 'a.`income_tax`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_LIFE_INSURANCE', 'a.`life_insurance`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_CASH_WITHDRAWALS', 'a.`cash_withdrawals`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_ACCOUNTS_PAYABLE', 'a.`accounts_payable`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_REPAYMENT_CASH_ADVANCE_PRINCIPAL', 'a.`repayment_cash_advance_principal`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_REPAYMENT_CASH_ADVANCE_INTEREST', 'a.`repayment_cash_advance_interest`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_ARREARS_PAYMENT', 'a.`arrears_payment`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_TERM_LOAN_PAYMENT_PRINCIPAL', 'a.`term_loan_payment_principal`', $listDirn, $listOrder); ?>
				</th>
				<th class='left'>
				<?php echo JHtml::_('searchtools.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_TERM_LOAN_PAYMENT_INTEREST', 'a.`term_loan_payment_interest`', $listDirn, $listOrder); ?>
				</th>

					
				</tr>
				</thead>
				<tfoot>
				<tr>
					<td colspan="<?php echo isset($this->items[0]) ? count(get_object_vars($this->items[0])) : 10; ?>">
						<?php echo $this->pagination->getListFooter(); ?>
					</td>
				</tr>
				</tfoot>
				<tbody>
				<?php foreach ($this->items as $i => $item) :
					$ordering   = ($listOrder == 'a.ordering');
					$canCreate  = $user->authorise('core.create', 'com_agmanager');
					$canEdit    = $user->authorise('core.edit', 'com_agmanager');
					$canCheckin = $user->authorise('core.manage', 'com_agmanager');
					$canChange  = $user->authorise('core.edit.state', 'com_agmanager');
					?>
					<tr class="row<?php echo $i % 2; ?>">

						<?php if (isset($this->items[0]->ordering)) : ?>
							<td class="order nowrap center hidden-phone">
								<?php if ($canChange) :
									$disableClassName = '';
									$disabledLabel    = '';

									if (!$saveOrder) :
										$disabledLabel    = Text::_('JORDERINGDISABLED');
										$disableClassName = 'inactive tip-top';
									endif; ?>
									<span class="sortable-handler hasTooltip <?php echo $disableClassName ?>"
										  title="<?php echo $disabledLabel ?>">
							<i class="icon-menu"></i>
						</span>
									<input type="text" style="display:none" name="order[]" size="5"
										   value="<?php echo $item->ordering; ?>" class="width-20 text-area-order "/>
								<?php else : ?>
									<span class="sortable-handler inactive">
							<i class="icon-menu"></i>
						</span>
								<?php endif; ?>
							</td>
						<?php endif; ?>
						<td >
							<?php echo HTMLHelper::_('grid.id', $i, $item->id); ?>
						</td>
						<?php if (isset($this->items[0]->state)): ?>
							
						<?php endif; ?>

										<td>

					<?php echo $item->seed_purchases; ?>
				</td>				<td>

					<?php echo $item->seed_cleaning; ?>
				</td>				<td>

					<?php echo $item->seed_treatment; ?>
				</td>				<td>

					<?php echo $item->fertilizer; ?>
				</td>				<td>

					<?php echo $item->chemicals; ?>
				</td>				<td>

					<?php echo $item->hailcrop_insurance; ?>
				</td>				<td>

					<?php echo $item->other_crop_expenses; ?>
				</td>				<td>

					<?php echo $item->grainhay_purchases; ?>
				</td>				<td>

					<?php echo $item->commercial_feed_purchases; ?>
				</td>				<td>

					<?php echo $item->salt; ?>
				</td>				<td>

					<?php echo $item->minerals; ?>
				</td>				<td>

					<?php echo $item->vitamins; ?>
				</td>				<td>

					<?php echo $item->pasture_rent; ?>
				</td>				<td>

					<?php echo $item->containers_twine; ?>
				</td>				<td>

					<?php echo $item->breeding_fees; ?>
				</td>				<td>

					<?php echo $item->vet_fees; ?>
				</td>				<td>

					<?php echo $item->drugs; ?>
				</td>				<td>

					<?php echo $item->breeding_stock_purchases; ?>
				</td>				<td>

					<?php echo $item->market_stock_purchases; ?>
				</td>				<td>

					<?php echo $item->marketing_charges; ?>
				</td>				<td>

					<?php echo $item->other_livestock_expenses; ?>
				</td>				<td>

					<?php echo $item->property_tax; ?>
				</td>				<td>

					<?php echo $item->capital_land_purchases; ?>
				</td>				<td>

					<?php echo $item->new_lease_payments; ?>
				</td>				<td>

					<?php echo $item->existing_lease_payments; ?>
				</td>				<td>

					<?php echo $item->annual_cash_rent_leased_land; ?>
				</td>				<td>

					<?php echo $item->fuel; ?>
				</td>				<td>

					<?php echo $item->oil; ?>
				</td>				<td>

					<?php echo $item->grease; ?>
				</td>				<td>

					<?php echo $item->equipment_repair; ?>
				</td>				<td>

					<?php echo $item->shop_supplies; ?>
				</td>				<td>

					<?php echo $item->small_tools; ?>
				</td>				<td>

					<?php echo $item->building_insurance; ?>
				</td>				<td>

					<?php echo $item->building_repairs; ?>
				</td>				<td>

					<?php echo $item->fence_repairs; ?>
				</td>				<td>

					<?php echo $item->vehicle_registrationinsurance; ?>
				</td>				<td>

					<?php echo $item->capital_machinesbuildings_purchases; ?>
				</td>				<td>

					<?php echo $item->professional_fees; ?>
				</td>				<td>

					<?php echo $item->custom_work; ?>
				</td>				<td>

					<?php echo $item->hydrotelephone; ?>
				</td>				<td>

					<?php echo $item->hired_labour; ?>
				</td>				<td>

					<?php echo $item->office_expenses; ?>
				</td>				<td>

					<?php echo $item->other_assetinvestment_purchases; ?>
				</td>				<td>

					<?php echo $item->other_farm_expenses; ?>
				</td>				<td>

					<?php echo $item->living_expenses; ?>
				</td>				<td>

					<?php echo $item->income_tax; ?>
				</td>				<td>

					<?php echo $item->life_insurance; ?>
				</td>				<td>

					<?php echo $item->cash_withdrawals; ?>
				</td>				<td>

					<?php echo $item->accounts_payable; ?>
				</td>				<td>

					<?php echo $item->repayment_cash_advance_principal; ?>
				</td>				<td>

					<?php echo $item->repayment_cash_advance_interest; ?>
				</td>				<td>

					<?php echo $item->arrears_payment; ?>
				</td>				<td>

					<?php echo $item->term_loan_payment_principal; ?>
				</td>				<td>

					<?php echo $item->term_loan_payment_interest; ?>
				</td>

					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<input type="hidden" name="task" value=""/>
			<input type="hidden" name="boxchecked" value="0"/>
            <input type="hidden" name="list[fullorder]" value="<?php echo $listOrder; ?> <?php echo $listDirn; ?>"/>
			<?php echo HTMLHelper::_('form.token'); ?>
		</div>
</form>
<script>
    window.toggleField = function (id, task, field) {

        var f = document.adminForm, i = 0, cbx, cb = f[ id ];

        if (!cb) return false;

        while (true) {
            cbx = f[ 'cb' + i ];

            if (!cbx) break;

            cbx.checked = false;
            i++;
        }

        var inputField   = document.createElement('input');

        inputField.type  = 'hidden';
        inputField.name  = 'field';
        inputField.value = field;
        f.appendChild(inputField);

        cb.checked = true;
        f.boxchecked.value = 1;
        Joomla.submitform(task);

        return false;
    };
</script>