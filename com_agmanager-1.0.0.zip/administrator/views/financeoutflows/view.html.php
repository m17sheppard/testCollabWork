<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Agmanager
 * @author     Micah Windle <support@bankert.ca>
 * @copyright  2021 Bankert Marketing Inc. 
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

use \Joomla\CMS\Language\Text;

/**
 * View class for a list of Agmanager.
 *
 * @since  1.6
 */
class AgmanagerViewFinanceoutflows extends \Joomla\CMS\MVC\View\HtmlView
{
	protected $items;

	protected $pagination;

	protected $state;

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  Template name
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	public function display($tpl = null)
	{
		$this->state = $this->get('State');
		$this->items = $this->get('Items');
		$this->pagination = $this->get('Pagination');
        $this->filterForm = $this->get('FilterForm');
        $this->activeFilters = $this->get('ActiveFilters');

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new Exception(implode("\n", $errors));
		}

		AgmanagerHelper::addSubmenu('financeoutflows');

		$this->addToolbar();

		$this->sidebar = JHtmlSidebar::render();
		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return void
	 *
	 * @since    1.6
	 */
	protected function addToolbar()
	{
		$state = $this->get('State');
		$canDo = AgmanagerHelper::getActions();

		JToolBarHelper::title(Text::_('COM_AGMANAGER_TITLE_FINANCEOUTFLOWS'), 'financeoutflows.png');

		// Check if the form exists before showing the add/edit buttons
		$formPath = JPATH_COMPONENT_ADMINISTRATOR . '/views/financesoutflow';

		if (file_exists($formPath))
		{
			if ($canDo->get('core.create'))
			{
				JToolBarHelper::addNew('financesoutflow.add', 'JTOOLBAR_NEW');

				if (isset($this->items[0]))
				{
					JToolbarHelper::custom('financeoutflows.duplicate', 'copy.png', 'copy_f2.png', 'JTOOLBAR_DUPLICATE', true);
				}
			}

			if ($canDo->get('core.edit') && isset($this->items[0]))
			{
				JToolBarHelper::editList('financesoutflow.edit', 'JTOOLBAR_EDIT');
			}
		}

		if ($canDo->get('core.edit.state'))
		{
			if (isset($this->items[0]->state))
			{
				JToolBarHelper::divider();
				JToolBarHelper::custom('financeoutflows.publish', 'publish.png', 'publish_f2.png', 'JTOOLBAR_PUBLISH', true);
				JToolBarHelper::custom('financeoutflows.unpublish', 'unpublish.png', 'unpublish_f2.png', 'JTOOLBAR_UNPUBLISH', true);
			}
			elseif (isset($this->items[0]))
			{
				// If this component does not use state then show a direct delete button as we can not trash
				JToolBarHelper::deleteList('', 'financeoutflows.delete', 'JTOOLBAR_DELETE');
			}

			if (isset($this->items[0]->state))
			{
				JToolBarHelper::divider();
				JToolBarHelper::archiveList('financeoutflows.archive', 'JTOOLBAR_ARCHIVE');
			}

			if (isset($this->items[0]->checked_out))
			{
				JToolBarHelper::custom('financeoutflows.checkin', 'checkin.png', 'checkin_f2.png', 'JTOOLBAR_CHECKIN', true);
			}
		}

		// Show trash and delete for components that uses the state field
		if (isset($this->items[0]->state))
		{
			if ($state->get('filter.state') == -2 && $canDo->get('core.delete'))
			{
				JToolBarHelper::deleteList('', 'financeoutflows.delete', 'JTOOLBAR_EMPTY_TRASH');
				JToolBarHelper::divider();
			}
			elseif ($canDo->get('core.edit.state'))
			{
				JToolBarHelper::trash('financeoutflows.trash', 'JTOOLBAR_TRASH');
				JToolBarHelper::divider();
			}
		}

		

		if ($canDo->get('core.admin'))
		{
			JToolBarHelper::preferences('com_agmanager');
		}

		// Set sidebar action - New in 3.0
		JHtmlSidebar::setAction('index.php?option=com_agmanager&view=financeoutflows');
	}

	/**
	 * Method to order fields 
	 *
	 * @return void 
	 */
	protected function getSortFields()
	{
		return array(
			'a.`grainhay_purchases`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_GRAINHAY_PURCHASES'),
			'a.`commercial_feed_purchases`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_COMMERCIAL_FEED_PURCHASES'),
			'a.`salt`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_SALT'),
			'a.`minerals`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_MINERALS'),
			'a.`vitamins`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_VITAMINS'),
			'a.`pasture_rent`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_PASTURE_RENT'),
			'a.`containers_twine`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_CONTAINERS_TWINE'),
			'a.`breeding_fees`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_BREEDING_FEES'),
			'a.`vet_fees`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_VET_FEES'),
			'a.`drugs`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_DRUGS'),
			'a.`breeding_stock_purchases`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_BREEDING_STOCK_PURCHASES'),
			'a.`market_stock_purchases`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_MARKET_STOCK_PURCHASES'),
			'a.`marketing_charges`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_MARKETING_CHARGES'),
			'a.`other_livestock_expenses`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_OTHER_LIVESTOCK_EXPENSES'),
			'a.`seed_purchases`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_SEED_PURCHASES'),
			'a.`seed_cleaning`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_SEED_CLEANING'),
			'a.`seed_treatment`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_SEED_TREATMENT'),
			'a.`fertilizer`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_FERTILIZER'),
			'a.`chemicals`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_CHEMICALS'),
			'a.`hailcrop_insurance`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_HAILCROP_INSURANCE'),
			'a.`other_crop_expenses`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_OTHER_CROP_EXPENSES'),
			'a.`property_tax`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_PROPERTY_TAX'),
			'a.`capital_land_purchases`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_CAPITAL_LAND_PURCHASES'),
			'a.`new_lease_payments`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_NEW_LEASE_PAYMENTS'),
			'a.`existing_lease_payments`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_EXISTING_LEASE_PAYMENTS'),
			'a.`annual_cash_rent_leased_land`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_ANNUAL_CASH_RENT_LEASED_LAND'),
			'a.`fuel`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_FUEL'),
			'a.`oil`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_OIL'),
			'a.`grease`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_GREASE'),
			'a.`equipment_repair`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_EQUIPMENT_REPAIR'),
			'a.`shop_supplies`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_SHOP_SUPPLIES'),
			'a.`small_tools`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_SMALL_TOOLS'),
			'a.`building_insurance`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_BUILDING_INSURANCE'),
			'a.`building_repairs`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_BUILDING_REPAIRS'),
			'a.`fence_repairs`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_FENCE_REPAIRS'),
			'a.`vehicle_registrationinsurance`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_VEHICLE_REGISTRATIONINSURANCE'),
			'a.`capital_machinesbuildings_purchases`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_CAPITAL_MACHINESBUILDINGS_PURCHASES'),
			'a.`professional_fees`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_PROFESSIONAL_FEES'),
			'a.`custom_work`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_CUSTOM_WORK'),
			'a.`hydrotelephone`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_HYDROTELEPHONE'),
			'a.`hired_labour`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_HIRED_LABOUR'),
			'a.`office_expenses`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_OFFICE_EXPENSES'),
			'a.`other_assetinvestment_purchases`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_OTHER_ASSETINVESTMENT_PURCHASES'),
			'a.`other_farm_expenses`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_OTHER_FARM_EXPENSES'),
			'a.`living_expenses`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_LIVING_EXPENSES'),
			'a.`income_tax`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_INCOME_TAX'),
			'a.`life_insurance`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_LIFE_INSURANCE'),
			'a.`cash_withdrawals`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_CASH_WITHDRAWALS'),
			'a.`accounts_payable`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_ACCOUNTS_PAYABLE'),
			'a.`repayment_cash_advance_principal`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_REPAYMENT_CASH_ADVANCE_PRINCIPAL'),
			'a.`repayment_cash_advance_interest`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_REPAYMENT_CASH_ADVANCE_INTEREST'),
			'a.`arrears_payment`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_ARREARS_PAYMENT'),
			'a.`term_loan_payment_principal`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_TERM_LOAN_PAYMENT_PRINCIPAL'),
			'a.`term_loan_payment_interest`' => JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_TERM_LOAN_PAYMENT_INTEREST'),
		);
	}

    /**
     * Check if state is set
     *
     * @param   mixed  $state  State
     *
     * @return bool
     */
    public function getState($state)
    {
        return isset($this->state->{$state}) ? $this->state->{$state} : false;
    }
}
