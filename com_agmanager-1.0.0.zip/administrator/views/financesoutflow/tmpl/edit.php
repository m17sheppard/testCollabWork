<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Agmanager
 * @author     Micah Windle <support@bankert.ca>
 * @copyright  2021 Bankert Marketing Inc. 
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;


HTMLHelper::addIncludePath(JPATH_COMPONENT . '/helpers/html');
HTMLHelper::_('behavior.tooltip');
HTMLHelper::_('behavior.formvalidation');
HTMLHelper::_('formbehavior.chosen', 'select');
HTMLHelper::_('behavior.keepalive');

// Import CSS
$document = Factory::getDocument();
$document->addStyleSheet(Uri::root() . 'media/com_agmanager/css/form.css');
?>
<script type="text/javascript">
	js = jQuery.noConflict();
	js(document).ready(function () {
		
	});

	Joomla.submitbutton = function (task) {
		if (task == 'financesoutflow.cancel') {
			Joomla.submitform(task, document.getElementById('financesoutflow-form'));
		}
		else {
			
			if (task != 'financesoutflow.cancel' && document.formvalidator.isValid(document.id('financesoutflow-form'))) {
				
				Joomla.submitform(task, document.getElementById('financesoutflow-form'));
			}
			else {
				alert('<?php echo $this->escape(Text::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
			}
		}
	}
</script>

<form
	action="<?php echo JRoute::_('index.php?option=com_agmanager&layout=edit&id=' . (int) $this->item->id); ?>"
	method="post" enctype="multipart/form-data" name="adminForm" id="financesoutflow-form" class="form-validate form-horizontal">

	
	<?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'livestockoutflow')); ?>
	<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'livestockoutflow', JText::_('COM_AGMANAGER_TAB_LIVESTOCKOUTFLOW', true)); ?>
	<div class="row-fluid">
		<div class="span10 form-horizontal">
			<fieldset class="adminform">
				<legend><?php echo JText::_('COM_AGMANAGER_FIELDSET_LIVESTOCKOUTFLOW'); ?></legend>
				<?php echo $this->form->renderField('grainhay_purchases'); ?>
				<?php echo $this->form->renderField('commercial_feed_purchases'); ?>
				<?php echo $this->form->renderField('salt'); ?>
				<?php echo $this->form->renderField('minerals'); ?>
				<?php echo $this->form->renderField('vitamins'); ?>
				<?php echo $this->form->renderField('pasture_rent'); ?>
				<?php echo $this->form->renderField('containers_twine'); ?>
				<?php echo $this->form->renderField('breeding_fees'); ?>
				<?php echo $this->form->renderField('vet_fees'); ?>
				<?php echo $this->form->renderField('drugs'); ?>
				<?php echo $this->form->renderField('breeding_stock_purchases'); ?>
				<?php echo $this->form->renderField('market_stock_purchases'); ?>
				<?php echo $this->form->renderField('marketing_charges'); ?>
				<?php echo $this->form->renderField('other_livestock_expenses'); ?>
				<?php echo $this->form->renderField('seed_purchases'); ?>
				<?php echo $this->form->renderField('seed_cleaning'); ?>
				<?php echo $this->form->renderField('seed_treatment'); ?>
				<?php echo $this->form->renderField('fertilizer'); ?>
				<?php echo $this->form->renderField('chemicals'); ?>
				<?php echo $this->form->renderField('hailcrop_insurance'); ?>
				<?php echo $this->form->renderField('other_crop_expenses'); ?>
				<?php echo $this->form->renderField('property_tax'); ?>
				<?php echo $this->form->renderField('capital_land_purchases'); ?>
				<?php echo $this->form->renderField('new_lease_payments'); ?>
				<?php echo $this->form->renderField('existing_lease_payments'); ?>
				<?php echo $this->form->renderField('annual_cash_rent_leased_land'); ?>
				<?php echo $this->form->renderField('fuel'); ?>
				<?php echo $this->form->renderField('oil'); ?>
				<?php echo $this->form->renderField('grease'); ?>
				<?php echo $this->form->renderField('equipment_repair'); ?>
				<?php echo $this->form->renderField('shop_supplies'); ?>
				<?php echo $this->form->renderField('small_tools'); ?>
				<?php echo $this->form->renderField('building_insurance'); ?>
				<?php echo $this->form->renderField('building_repairs'); ?>
				<?php echo $this->form->renderField('fence_repairs'); ?>
				<?php echo $this->form->renderField('vehicle_registrationinsurance'); ?>
				<?php echo $this->form->renderField('capital_machinesbuildings_purchases'); ?>
				<?php echo $this->form->renderField('professional_fees'); ?>
				<?php echo $this->form->renderField('custom_work'); ?>
				<?php echo $this->form->renderField('hydrotelephone'); ?>
				<?php echo $this->form->renderField('hired_labour'); ?>
				<?php echo $this->form->renderField('office_expenses'); ?>
				<?php echo $this->form->renderField('other_assetinvestment_purchases'); ?>
				<?php echo $this->form->renderField('other_farm_expenses'); ?>
				<?php echo $this->form->renderField('living_expenses'); ?>
				<?php echo $this->form->renderField('income_tax'); ?>
				<?php echo $this->form->renderField('life_insurance'); ?>
				<?php echo $this->form->renderField('cash_withdrawals'); ?>
				<?php echo $this->form->renderField('accounts_payable'); ?>
				<?php echo $this->form->renderField('repayment_cash_advance_principal'); ?>
				<?php echo $this->form->renderField('repayment_cash_advance_interest'); ?>
				<?php echo $this->form->renderField('arrears_payment'); ?>
				<?php echo $this->form->renderField('term_loan_payment_principal'); ?>
				<?php echo $this->form->renderField('term_loan_payment_interest'); ?>
			</fieldset>
		</div>
	</div>
	<?php echo JHtml::_('bootstrap.endTab'); ?>
	<input type="hidden" name="jform[id]" value="<?php echo $this->item->id; ?>" />
	<input type="hidden" name="jform[ordering]" value="<?php echo $this->item->ordering; ?>" />
	<input type="hidden" name="jform[state]" value="<?php echo $this->item->state; ?>" />
	<input type="hidden" name="jform[checked_out]" value="<?php echo $this->item->checked_out; ?>" />
	<input type="hidden" name="jform[checked_out_time]" value="<?php echo $this->item->checked_out_time; ?>" />
	<?php echo $this->form->renderField('created_by'); ?>
	<?php echo $this->form->renderField('modified_by'); ?>

	

	<?php $this->ignore_fieldsets = array('general', 'info', 'detail', 'jmetadata', 'item_associations', 'accesscontrol'); ?>
	<?php echo JLayoutHelper::render('joomla.edit.params', $this); ?>
	
	<?php echo JHtml::_('bootstrap.endTabSet'); ?>

	<input type="hidden" name="task" value=""/>
	<?php echo JHtml::_('form.token'); ?>

</form>
