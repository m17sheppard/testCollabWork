<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Agmanager
 * @author     Micah Windle <support@bankert.ca>
 * @copyright  2021 Bankert Marketing Inc. 
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;


HTMLHelper::addIncludePath(JPATH_COMPONENT . '/helpers/html');
HTMLHelper::_('behavior.tooltip');
HTMLHelper::_('behavior.formvalidation');
HTMLHelper::_('formbehavior.chosen', 'select');
HTMLHelper::_('behavior.keepalive');

// Import CSS
$document = Factory::getDocument();
$document->addStyleSheet(Uri::root() . 'media/com_agmanager/css/form.css');
?>
<script type="text/javascript">
	js = jQuery.noConflict();
	js(document).ready(function () {
		
	js('input:hidden.seed_supplier').each(function(){
		var name = js(this).attr('name');
		if(name.indexOf('seed_supplierhidden')){
			js('#jform_seed_supplier option[value="'+js(this).val()+'"]').attr('selected',true);
		}
	});
	js("#jform_seed_supplier").trigger("liszt:updated");
	});

	Joomla.submitbutton = function (task) {
		if (task == 'seed.cancel') {
			Joomla.submitform(task, document.getElementById('seed-form'));
		}
		else {
			
			if (task != 'seed.cancel' && document.formvalidator.isValid(document.id('seed-form'))) {
				
				Joomla.submitform(task, document.getElementById('seed-form'));
			}
			else {
				alert('<?php echo $this->escape(Text::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
			}
		}
	}
</script>

<form
	action="<?php echo JRoute::_('index.php?option=com_agmanager&layout=edit&id=' . (int) $this->item->id); ?>"
	method="post" enctype="multipart/form-data" name="adminForm" id="seed-form" class="form-validate form-horizontal">

	
	<?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'managementchemicaltype')); ?>
	<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'managementchemicaltype', JText::_('COM_AGMANAGER_TAB_MANAGEMENTCHEMICALTYPE', true)); ?>
	<div class="row-fluid">
		<div class="span10 form-horizontal">
			<fieldset class="adminform">
				<legend><?php echo JText::_('COM_AGMANAGER_FIELDSET_MANAGEMENTCHEMICALTYPE'); ?></legend>
				<?php echo $this->form->renderField('crop_type'); ?>
				<?php echo $this->form->renderField('crop_cost'); ?>
				<?php echo $this->form->renderField('crop_per_acre'); ?>
				<?php echo $this->form->renderField('crop_quantity'); ?>
				<?php echo $this->form->renderField('seed_supplier'); ?>
				<?php
				foreach((array)$this->item->seed_supplier as $value)
				{
					if(!is_array($value))
					{
						echo '<input type="hidden" class="seed_supplier" name="jform[seed_supplierhidden]['.$value.']" value="'.$value.'" />';
					}
				}
				?>
			</fieldset>
		</div>
	</div>
	<?php echo JHtml::_('bootstrap.endTab'); ?>
	<input type="hidden" name="jform[id]" value="<?php echo $this->item->id; ?>" />
	<input type="hidden" name="jform[state]" value="<?php echo $this->item->state; ?>" />
	<input type="hidden" name="jform[checked_out]" value="<?php echo $this->item->checked_out; ?>" />
	<input type="hidden" name="jform[checked_out_time]" value="<?php echo $this->item->checked_out_time; ?>" />
	<?php echo $this->form->renderField('created_by'); ?>
	<?php echo $this->form->renderField('modified_by'); ?>
	<input type="hidden" name="jform[lft]" value="<?php echo $this->item->lft; ?>" />
	<input type="hidden" name="jform[rgt]" value="<?php echo $this->item->rgt; ?>" />
	<input type="hidden" name="jform[level]" value="<?php echo $this->item->level; ?>" />
	<input type="hidden" name="jform[access]" value="<?php echo $this->item->access; ?>" />
	<input type="hidden" name="jform[path]" value="<?php echo $this->item->path; ?>" />

	

	<?php $this->ignore_fieldsets = array('general', 'info', 'detail', 'jmetadata', 'item_associations', 'accesscontrol'); ?>
	<?php echo JLayoutHelper::render('joomla.edit.params', $this); ?>
	
	<?php echo JHtml::_('bootstrap.endTabSet'); ?>

	<input type="hidden" name="task" value=""/>
	<?php echo JHtml::_('form.token'); ?>

</form>
