/**
 * @version     CVS: 1.0.0
 * @package     com_agmanager
 * @subpackage  mod_agmanager
 * @copyright   2021 Bankert Marketing Inc. 
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Micah Windle <support@bankert.ca>
 */


