<?php

/**
 * @version     CVS: 1.0.0
 * @package     com_agmanager
 * @subpackage  mod_agmanager
 * @author      Micah Windle <support@bankert.ca>
 * @copyright   2021 Bankert Marketing Inc. 
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;

/**
 * Helper for mod_agmanager
 *
 * @package     com_agmanager
 * @subpackage  mod_agmanager
 * @since       1.6
 */
class ModAgmanagerHelper
{
	/**
	 * Retrieve component items
	 *
	 * @param   Joomla\Registry\Registry &$params module parameters
	 *
	 * @return array Array with all the elements
     *
     * @throws Exception
	 */
	public static function getList(&$params)
	{
		$app   = Factory::getApplication();
		$db    = Factory::getDbo();
		$query = $db->getQuery(true);

		$tableField = explode(':', $params->get('field'));
		$table_name = !empty($tableField[0]) ? $tableField[0] : '';

		/* @var $params Joomla\Registry\Registry */
		$query
			->select('*')
			->from($table_name)
			->where('state = 1');

		$db->setQuery($query, $app->input->getInt('offset', (int) $params->get('offset')), $app->input->getInt('limit', (int) $params->get('limit')));
		$rows = $db->loadObjectList();

		return $rows;
	}

	/**
	 * Retrieve component items
	 *
	 * @param   Joomla\Registry\Registry &$params module parameters
	 *
	 * @return mixed stdClass object if the item was found, null otherwise
	 */
	public static function getItem(&$params)
	{
		$db    = Factory::getDbo();
		$query = $db->getQuery(true);

		/* @var $params Joomla\Registry\Registry */
		$query
			->select('*')
			->from($params->get('item_table'))
			->where('id = ' . intval($params->get('item_id')));

		$db->setQuery($query);
		$element = $db->loadObject();

		return $element;
	}

	/**
	 * Render element
	 *
	 * @param   Joomla\Registry\Registry $table_name  Table name
	 * @param   string                   $field_name  Field name
	 * @param   string                   $field_value Field value
	 *
	 * @return string
	 */
	public static function renderElement($table_name, $field_name, $field_value)
	{
		$result = '';
		
		if(strpos($field_name, ':'))
		{
			$tableField = explode(':', $field_name);
			$table_name = !empty($tableField[0]) ? $tableField[0] : '';
			$field_name = !empty($tableField[1]) ? $tableField[1] : '';
		}
		
		switch ($table_name)
		{
			
		case '#__agmanager_crop_plan':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'location_legal':
		$result = $field_value;
		break;
		case 'location_acreage':
		$result = $field_value;
		break;
		case 'plan_crop':
		$result = self::loadValueFromExternalTable('#__agmanager_seed', 'crop_type', 'crop_type', $field_value);
		break;
		case 'plan_fertilizer':
		$result = self::loadValueFromExternalTable('#__agmanager_fertilizer', 'fert_type', 'fert_type', $field_value);
		break;
		case 'plan_chemical':
		$result = self::loadValueFromExternalTable('#__agmanager_chemical', 'chem_type', 'chem_type', $field_value);
		break;
		case 'cost_seed':
		$result = self::loadValueFromExternalTable('#__agmanager_seed', 'crop_per_acre', 'crop_per_acre', $field_value);
		break;
		case 'cost_fert':
		$result = self::loadValueFromExternalTable('#__agmanager_fertilizer', 'fert_per_acre', 'fert_per_acre', $field_value);
		break;
		case 'cost_chem':
		$result = self::loadValueFromExternalTable('#__agmanager_chemical', 'chem_per_acre', 'chem_per_acre', $field_value);
		break;
		}
		break;
		case '#__agmanager_seed':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'lft':
		$result = $field_value;
		break;
		case 'rgt':
		$result = $field_value;
		break;
		case 'level':
		$result = $field_value;
		break;
		case 'access':
		$result = $field_value;
		break;
		case 'path':
		$result = $field_value;
		break;
		case 'crop_type':
		$result = $field_value;
		break;
		case 'crop_cost':
		$result = $field_value;
		break;
		case 'crop_per_acre':
		$result = $field_value;
		break;
		case 'crop_quantity':
		$result = $field_value;
		break;
		case 'seed_supplier':
		$result = self::loadValueFromExternalTable('#__agmanager_seedsuppliers', 'suppliername', 'suppliername', $field_value);
		break;
		}
		break;
		case '#__agmanager_fertilizer':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'lft':
		$result = $field_value;
		break;
		case 'rgt':
		$result = $field_value;
		break;
		case 'level':
		$result = $field_value;
		break;
		case 'access':
		$result = $field_value;
		break;
		case 'path':
		$result = $field_value;
		break;
		case 'fert_type':
		$result = $field_value;
		break;
		case 'fert_cost':
		$result = $field_value;
		break;
		case 'fert_per_acre':
		$result = $field_value;
		break;
		case 'fert_quantity':
		$result = $field_value;
		break;
		}
		break;
		case '#__agmanager_chemical':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'lft':
		$result = $field_value;
		break;
		case 'rgt':
		$result = $field_value;
		break;
		case 'level':
		$result = $field_value;
		break;
		case 'access':
		$result = $field_value;
		break;
		case 'path':
		$result = $field_value;
		break;
		case 'chem_type':
		$result = $field_value;
		break;
		case 'chem_quantity':
		$result = $field_value;
		break;
		case 'chem_cost':
		$result = $field_value;
		break;
		case 'chem_per_acre':
		$result = $field_value;
		break;
		}
		break;
		case '#__agmanager_seedsuppliers':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'suppliername':
		$result = $field_value;
		break;
		}
		break;
		case '#__agmanager_livestock':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'livestock_category':
		$result = $field_value;
		break;
		case 'tag_number':
		$result = $field_value;
		break;
		case 'transin_date':
		$result = $field_value;
		break;
		case 'transin_mode':
		$result = $field_value;
		break;
		case 'transin_weight':
		$result = $field_value;
		break;
		case 'transout_mode':
		$result = $field_value;
		break;
		case 'transout_date':
		$result = $field_value;
		break;
		case 'transout_weight':
		$result = $field_value;
		break;
		case 'purchase_price':
		$result = $field_value;
		break;
		case 'sale_price':
		$result = $field_value;
		break;
		}
		break;
		case '#__agmanager_owned_land':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'legal_description':
		$result = $field_value;
		break;
		case 'owner':
		$result = $field_value;
		break;
		case 'total_acreage':
		$result = $field_value;
		break;
		case 'year_acquired':
		$result = $field_value;
		break;
		case 'purchase_price':
		$result = $field_value;
		break;
		case 'assessed_value':
		$result = $field_value;
		break;
		case 'farmq':
		$result = $field_value;
		break;
		case 'cultivated_acreage':
		$result = $field_value;
		break;
		case 'market_value':
		$result = $field_value;
		break;
		case 'encumbrance':
		$result = $field_value;
		break;
		case 'purchases':
		$result = $field_value;
		break;
		case 'sales':
		$result = $field_value;
		break;
		case 'asset_gainloss':
		$result = $field_value;
		break;
		case 'owned_leased':
		$result = $field_value;
		break;
		case 'lease_years_remaining':
		$result = $field_value;
		break;
		case 'lease_expiration':
		$result = $field_value;
		break;
		}
		break;
		case '#__agmanager_leased_land':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'farmq_options':
		$result = $field_value;
		break;
		case 'legal_description':
		$result = $field_value;
		break;
		case 'owner':
		$result = $field_value;
		break;
		case 'total_acreage':
		$result = $field_value;
		break;
		case 'year_acquired':
		$result = $field_value;
		break;
		case 'purchase_price':
		$result = $field_value;
		break;
		case 'assessed_value':
		$result = $field_value;
		break;
		case 'farmq':
		$result = $field_value;
		break;
		case 'cultivated_acreage':
		$result = $field_value;
		break;
		case 'market_value':
		$result = $field_value;
		break;
		case 'encumbrance':
		$result = $field_value;
		break;
		case 'purchases':
		$result = $field_value;
		break;
		case 'sales':
		$result = $field_value;
		break;
		case 'asset_gainloss':
		$result = $field_value;
		break;
		}
		break;
		case '#__agmanager_building_quota':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'name':
		$result = $field_value;
		break;
		case 'construction_date':
		$result = $field_value;
		break;
		case 'location':
		$result = $field_value;
		break;
		case 'assessed_value':
		$result = $field_value;
		break;
		case 'year_acquired':
		$result = $field_value;
		break;
		case 'market_value':
		$result = $field_value;
		break;
		case 'purchases':
		$result = $field_value;
		break;
		case 'sales':
		$result = $field_value;
		break;
		case 'asset_gainloss':
		$result = $field_value;
		break;
		case 'condition':
		$result = $field_value;
		break;
		case 'maintenance':
		$result = $field_value;
		break;
		case 'comments':
		$result = $field_value;
		break;
		case 'attachments':
						if (!empty($field_value)) {
							$result = JPATH_ADMINISTRATOR . 'components/com_agmanager//' . $field_value;
						} else {
							$result = $field_value;
						}
		break;
		case 'maintenance_frequency':
		$result = $field_value;
		break;
		}
		break;
		case '#__agmanager_bins':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'description':
		$result = $field_value;
		break;
		case 'construction_date':
		$result = $field_value;
		break;
		case 'quantity':
		$result = $field_value;
		break;
		case 'capacity_per_unit':
		$result = $field_value;
		break;
		case 'total_capacity':
		$result = $field_value;
		break;
		case 'market_value':
		$result = $field_value;
		break;
		case 'purchases':
		$result = $field_value;
		break;
		case 'sales':
		$result = $field_value;
		break;
		case 'asset_gainloss':
		$result = $field_value;
		break;
		case 'condition':
		$result = $field_value;
		break;
		case 'maintenance':
		$result = $field_value;
		break;
		case 'comments':
		$result = $field_value;
		break;
		case 'attachments':
						if (!empty($field_value)) {
							$result = JPATH_ADMINISTRATOR . 'components/com_agmanager//' . $field_value;
						} else {
							$result = $field_value;
						}
		break;
		case 'maintenance_frequency':
		$result = $field_value;
		break;
		}
		break;
		case '#__agmanager_machinery_equipment':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'unit':
		$result = $field_value;
		break;
		case 'make':
		$result = $field_value;
		break;
		case 'model':
		$result = $field_value;
		break;
		case 'manufacture_date':
		$result = $field_value;
		break;
		case 'purchase_date':
		$result = $field_value;
		break;
		case 'market_value':
		$result = $field_value;
		break;
		case 'purchases':
		$result = $field_value;
		break;
		case 'sales':
		$result = $field_value;
		break;
		case 'asset_gainloss':
		$result = $field_value;
		break;
		case 'condition':
		$result = $field_value;
		break;
		case 'maintenance':
		$result = $field_value;
		break;
		case 'comments':
		$result = $field_value;
		break;
		case 'attachments':
						if (!empty($field_value)) {
							$result = JPATH_ADMINISTRATOR . 'components/com_agmanager//' . $field_value;
						} else {
							$result = $field_value;
						}
		break;
		case 'purchase_price':
		$result = $field_value;
		break;
		case 'maintenance_frequency':
		$result = $field_value;
		break;
		}
		break;
		case '#__agmanager_debts':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'type':
		$result = $field_value;
		break;
		case 'original_date':
		$result = $field_value;
		break;
		case 'original_amount':
		$result = $field_value;
		break;
		case 'principal_loan':
		$result = $field_value;
		break;
		case 'years_remaining':
		$result = $field_value;
		break;
		case 'annual_rent':
		$result = $field_value;
		break;
		case 'accrued_interest':
		$result = $field_value;
		break;
		case 'arrears':
		$result = $field_value;
		break;
		case 'total_amount_outstanding':
		$result = $field_value;
		break;
		case 'payment_date':
		$result = $field_value;
		break;
		case 'crop_share':
		$result = $field_value;
		break;
		case 'lease_terms':
		$result = $field_value;
		break;
		}
		break;
		case '#__agmanager_finances_inflow':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'custom_work':
		$result = $field_value;
		break;
		case 'accounts_receivable':
		$result = $field_value;
		break;
		case 'other_farm_income':
		$result = $field_value;
		break;
		case 'new_cash_advance':
		$result = $field_value;
		break;
		case 'new_term_borrowings':
		$result = $field_value;
		break;
		case 'other_asset_sales':
		$result = $field_value;
		break;
		case 'off_farm_income':
		$result = $field_value;
		break;
		case 'cash_contributions':
		$result = $field_value;
		break;
		case 'crop_sales':
		$result = $field_value;
		break;
		case 'breedinglivestocksales':
		$result = $field_value;
		break;
		case 'market_livestock_sales':
		$result = $field_value;
		break;
		case 'livestock_products':
		$result = $field_value;
		break;
		case 'capital_land_sales':
		$result = $field_value;
		break;
		case 'capital_machinebuilding_sales':
		$result = $field_value;
		break;
		}
		break;
		case '#__agmanager_finances_outflow':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'grainhay_purchases':
		$result = $field_value;
		break;
		case 'commercial_feed_purchases':
		$result = $field_value;
		break;
		case 'salt':
		$result = $field_value;
		break;
		case 'minerals':
		$result = $field_value;
		break;
		case 'vitamins':
		$result = $field_value;
		break;
		case 'pasture_rent':
		$result = $field_value;
		break;
		case 'containers_twine':
		$result = $field_value;
		break;
		case 'breeding_fees':
		$result = $field_value;
		break;
		case 'vet_fees':
		$result = $field_value;
		break;
		case 'drugs':
		$result = $field_value;
		break;
		case 'breeding_stock_purchases':
		$result = $field_value;
		break;
		case 'market_stock_purchases':
		$result = $field_value;
		break;
		case 'marketing_charges':
		$result = $field_value;
		break;
		case 'other_livestock_expenses':
		$result = $field_value;
		break;
		case 'seed_purchases':
		$result = $field_value;
		break;
		case 'seed_cleaning':
		$result = $field_value;
		break;
		case 'seed_treatment':
		$result = $field_value;
		break;
		case 'fertilizer':
		$result = $field_value;
		break;
		case 'chemicals':
		$result = $field_value;
		break;
		case 'hailcrop_insurance':
		$result = $field_value;
		break;
		case 'other_crop_expenses':
		$result = $field_value;
		break;
		case 'property_tax':
		$result = $field_value;
		break;
		case 'capital_land_purchases':
		$result = $field_value;
		break;
		case 'new_lease_payments':
		$result = $field_value;
		break;
		case 'existing_lease_payments':
		$result = $field_value;
		break;
		case 'annual_cash_rent_leased_land':
		$result = $field_value;
		break;
		case 'fuel':
		$result = $field_value;
		break;
		case 'oil':
		$result = $field_value;
		break;
		case 'grease':
		$result = $field_value;
		break;
		case 'equipment_repair':
		$result = $field_value;
		break;
		case 'shop_supplies':
		$result = $field_value;
		break;
		case 'small_tools':
		$result = $field_value;
		break;
		case 'building_insurance':
		$result = $field_value;
		break;
		case 'building_repairs':
		$result = $field_value;
		break;
		case 'fence_repairs':
		$result = $field_value;
		break;
		case 'vehicle_registrationinsurance':
		$result = $field_value;
		break;
		case 'capital_machinesbuildings_purchases':
		$result = $field_value;
		break;
		case 'professional_fees':
		$result = $field_value;
		break;
		case 'custom_work':
		$result = $field_value;
		break;
		case 'hydrotelephone':
		$result = $field_value;
		break;
		case 'hired_labour':
		$result = $field_value;
		break;
		case 'office_expenses':
		$result = $field_value;
		break;
		case 'other_assetinvestment_purchases':
		$result = $field_value;
		break;
		case 'other_farm_expenses':
		$result = $field_value;
		break;
		case 'living_expenses':
		$result = $field_value;
		break;
		case 'income_tax':
		$result = $field_value;
		break;
		case 'life_insurance':
		$result = $field_value;
		break;
		case 'cash_withdrawals':
		$result = $field_value;
		break;
		case 'accounts_payable':
		$result = $field_value;
		break;
		case 'repayment_cash_advance_principal':
		$result = $field_value;
		break;
		case 'repayment_cash_advance_interest':
		$result = $field_value;
		break;
		case 'arrears_payment':
		$result = $field_value;
		break;
		case 'term_loan_payment_principal':
		$result = $field_value;
		break;
		case 'term_loan_payment_interest':
		$result = $field_value;
		break;
		}
		break;
		case '#__agmanager_finances_assets':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'cash_on_hand':
		$result = $field_value;
		break;
		case 'accounts_receivable':
		$result = $field_value;
		break;
		case 'market_livestock':
		$result = $field_value;
		break;
		case 'grain':
		$result = $field_value;
		break;
		case 'farm_supplies':
		$result = $field_value;
		break;
		case 'investment_growing_crops':
		$result = $field_value;
		break;
		}
		break;
		case '#__agmanager_accounts_payable_types':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'account_type':
		$result = $field_value;
		break;
		}
		break;
		case '#__agmanager_payments_projection':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'annual_interest_payment':
		$result = $field_value;
		break;
		case 'first_interest_duedate':
		$result = $field_value;
		break;
		case 'principal_payment_increment':
		$result = $field_value;
		break;
		case 'first_principle_due':
		$result = $field_value;
		break;
		case 'annual_arrears_payment':
		$result = $field_value;
		break;
		case 'final_interest_date':
		$result = $field_value;
		break;
		case 'projected_interest_yearend':
		$result = $field_value;
		break;
		}
		break;
		}

		return $result;
	}

	/**
	 * Returns the translatable name of the element
	 *
	 * @param   string .................. $table_name table name
	 * @param   string                   $field   Field name
	 *
	 * @return string Translatable name.
	 */
	public static function renderTranslatableHeader($table_name, $field)
	{
		return Text::_(
			'MOD_AGMANAGER_HEADER_FIELD_' . str_replace('#__', '', strtoupper($table_name)) . '_' . strtoupper($field)
		);
	}

	/**
	 * Checks if an element should appear in the table/item view
	 *
	 * @param   string $field name of the field
	 *
	 * @return boolean True if it should appear, false otherwise
	 */
	public static function shouldAppear($field)
	{
		$noHeaderFields = array('checked_out_time', 'checked_out', 'ordering', 'state');

		return !in_array($field, $noHeaderFields);
	}

	

    /**
     * Method to get a value from a external table
     * @param string $source_table Source table name
     * @param string $key_field Source key field 
     * @param string $value_field Source value field
     * @param mixed  $key_value Value for the key field
     * @return mixed The value in the external table or null if it wasn't found
     */
    private static function loadValueFromExternalTable($source_table, $key_field, $value_field, $key_value) {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);

        $query
                ->select($db->quoteName($value_field))
                ->from($source_table)
                ->where($db->quoteName($key_field) . ' = ' . $db->quote($key_value));


        $db->setQuery($query);
        return $db->loadResult();
    }
}
