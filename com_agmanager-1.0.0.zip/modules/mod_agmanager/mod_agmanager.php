<?php

/**
 * @version     CVS: 1.0.0
 * @package     com_agmanager
 * @subpackage  mod_agmanager
 * @author      Micah Windle <support@bankert.ca>
 * @copyright   2021 Bankert Marketing Inc. 
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Helper\ModuleHelper;

// Include the syndicate functions only once
JLoader::register('ModAgmanagerHelper', dirname(__FILE__) . '/helper.php');

$doc = Factory::getDocument();

/* */
$doc->addStyleSheet(URI::base() . 'media/mod_agmanager/css/style.css');

/* */
$doc->addScript(URI::base() . 'media/mod_agmanager/js/script.js');

require ModuleHelper::getLayoutPath('mod_agmanager', $params->get('content_type', 'blank'));
