<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Agmanager
 * @author     Micah Windle <support@bankert.ca>
 * @copyright  2021 Bankert Marketing Inc. 
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\CMS\Layout\FileLayout;
use \Joomla\Utilities\ArrayHelper;

/**
 * Methods supporting a list of Agmanager records.
 *
 * @since  1.6
 */
class AgmanagerModelCropplans extends \Joomla\CMS\MVC\Model\ListModel
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @see        JController
	 * @since      1.6
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id', 'a.id',
				'ordering', 'a.ordering',
				'state', 'a.state',
				'created_by', 'a.created_by',
				'modified_by', 'a.modified_by',
				'location_legal', 'a.location_legal',
				'location_acreage', 'a.location_acreage',
				'plan_crop', 'a.plan_crop',
				'plan_fertilizer', 'a.plan_fertilizer',
				'plan_chemical', 'a.plan_chemical',
				'cost_seed', 'a.cost_seed',
				'cost_fert', 'a.cost_fert',
				'cost_chem', 'a.cost_chem',
			);
		}

		parent::__construct($config);
	}

        
       /**
        * Checks whether or not a user is manager or super user
        *
        * @return bool
        */
        public function isAdminOrSuperUser()
        {
            try{
                $user = JFactory::getUser();
                return in_array("8", $user->groups) || in_array("7", $user->groups);
            }catch(Exception $exc){
                return false;
            }
        }
        
	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return void
	 *
	 * @throws Exception
	 *
	 * @since    1.6
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		$app  = Factory::getApplication();
            
		$list = $app->getUserState($this->context . '.list');

		$ordering  = isset($list['filter_order'])     ? $list['filter_order']     : null;
		$direction = isset($list['filter_order_Dir']) ? $list['filter_order_Dir'] : null;
		if(empty($ordering)){
		$ordering = $app->getUserStateFromRequest($this->context . '.filter_order', 'filter_order', $app->get('filter_order'));
		if (!in_array($ordering, $this->filter_fields))
		{
		$ordering = '';
		}
		$this->setState('list.ordering', $ordering);
		}
		if(empty($direction))
		{
		$direction = $app->getUserStateFromRequest($this->context . '.filter_order_Dir', 'filter_order_Dir', $app->get('filter_order_Dir'));
		if (!in_array(strtoupper($direction), array('ASC', 'DESC', '')))
		{
		$direction = 'ASC';
		}
		$this->setState('list.direction', $direction);
		}

		$list['limit']     = $app->getUserStateFromRequest($this->context . '.list.limit', 'limit', $app->get('list_limit'), 'uint');
		$list['start']     = $app->input->getInt('start', 0);
		$list['ordering']  = $ordering;
		$list['direction'] = $direction;

		$app->setUserState($this->context . '.list', $list);
		$app->input->set('list', null);
           
            
        // List state information.

        parent::populateState($ordering, $direction);

        $context = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
        $this->setState('filter.search', $context);

        

        // Load the parameters.
		$params = $app->getParams();
		$this->setState('params', $params);

        // Split context into component and optional section
        $parts = FieldsHelper::extract($context);

        if ($parts)
        {
            $this->setState('filter.component', $parts[0]);
            $this->setState('filter.section', $parts[1]);
        }
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return   JDatabaseQuery
	 *
	 * @since    1.6
	 */
	protected function getListQuery()
	{
            // Create a new query object.
            $db    = $this->getDbo();
            $query = $db->getQuery(true);

            // Select the required fields from the table.
            $query->select(
                        $this->getState(
                                'list.select', 'DISTINCT a.*'
                        )
                );

            $query->from('`#__agmanager_crop_plan` AS a');
            
		// Join over the users for the checked out user.
		$query->select('uc.name AS uEditor');
		$query->join('LEFT', '#__users AS uc ON uc.id=a.checked_out');

		// Join over the created by field 'created_by'
		$query->join('LEFT', '#__users AS created_by ON created_by.id = a.created_by');

		// Join over the created by field 'modified_by'
		$query->join('LEFT', '#__users AS modified_by ON modified_by.id = a.modified_by');
		// Join over the foreign key 'plan_crop'
		$query->select('`#__agmanager_seed_3603915`.`crop_type` AS seeds_fk_value_3603915');
		$query->join('LEFT', '#__agmanager_seed AS #__agmanager_seed_3603915 ON #__agmanager_seed_3603915.`crop_type` = a.`plan_crop`');
		// Join over the foreign key 'plan_fertilizer'
		$query->select('`#__agmanager_fertilizer_3603916`.`fert_type` AS fertilizers_fk_value_3603916');
		$query->join('LEFT', '#__agmanager_fertilizer AS #__agmanager_fertilizer_3603916 ON #__agmanager_fertilizer_3603916.`fert_type` = a.`plan_fertilizer`');
		// Join over the foreign key 'plan_chemical'
		$query->select('`#__agmanager_chemical_3603917`.`chem_type` AS chemicals_fk_value_3603917');
		$query->join('LEFT', '#__agmanager_chemical AS #__agmanager_chemical_3603917 ON #__agmanager_chemical_3603917.`chem_type` = a.`plan_chemical`');
		// Join over the foreign key 'cost_seed'
		$query->select('`#__agmanager_seed_3603918`.`crop_per_acre` AS seeds_fk_value_3603918');
		$query->join('LEFT', '#__agmanager_seed AS #__agmanager_seed_3603918 ON #__agmanager_seed_3603918.`crop_per_acre` = a.`cost_seed`');
		// Join over the foreign key 'cost_fert'
		$query->select('`#__agmanager_fertilizer_3603919`.`fert_per_acre` AS fertilizers_fk_value_3603919');
		$query->join('LEFT', '#__agmanager_fertilizer AS #__agmanager_fertilizer_3603919 ON #__agmanager_fertilizer_3603919.`fert_per_acre` = a.`cost_fert`');
		// Join over the foreign key 'cost_chem'
		$query->select('`#__agmanager_chemical_3603920`.`chem_per_acre` AS chemicals_fk_value_3603920');
		$query->join('LEFT', '#__agmanager_chemical AS #__agmanager_chemical_3603920 ON #__agmanager_chemical_3603920.`chem_per_acre` = a.`cost_chem`');
		if(!$this->isAdminOrSuperUser()){
			$query->where("a.created_by = " . JFactory::getUser()->get("id"));
		}
            
		if (!Factory::getUser()->authorise('core.edit', 'com_agmanager'))
		{
			$query->where('a.state = 1');
		}
		else
		{
			$query->where('(a.state IN (0, 1))');
		}

            // Filter by search in title
            $search = $this->getState('filter.search');

            if (!empty($search))
            {
                if (stripos($search, 'id:') === 0)
                {
                    $query->where('a.id = ' . (int) substr($search, 3));
                }
                else
                {
                    $search = $db->Quote('%' . $db->escape($search, true) . '%');
					$query->where('( a.location_legal LIKE ' . $search . '  OR #__agmanager_seed_3603915.crop_type LIKE ' . $search . '  OR #__agmanager_fertilizer_3603916.fert_type LIKE ' . $search . '  OR #__agmanager_chemical_3603917.chem_type LIKE ' . $search . '  OR #__agmanager_fertilizer_3603919.fert_per_acre LIKE ' . $search . ' )');
                }
            }
            

		// Filtering plan_crop
		$filter_plan_crop = $this->state->get("filter.plan_crop");

		if ($filter_plan_crop)
		{
			$query->where("FIND_IN_SET('" . $db->escape($filter_plan_crop) . "',a.plan_crop)");
		}

		// Filtering plan_fertilizer
		$filter_plan_fertilizer = $this->state->get("filter.plan_fertilizer");

		if ($filter_plan_fertilizer)
		{
			$query->where("FIND_IN_SET('" . $db->escape($filter_plan_fertilizer) . "',a.plan_fertilizer)");
		}

		// Filtering plan_chemical
		$filter_plan_chemical = $this->state->get("filter.plan_chemical");

		if ($filter_plan_chemical)
		{
			$query->where("FIND_IN_SET('" . $db->escape($filter_plan_chemical) . "',a.plan_chemical)");
		}

            
            
            // Add the list ordering clause.
            $orderCol  = $this->state->get('list.ordering', '');
            $orderDirn = $this->state->get('list.direction', 'ASC');

            if ($orderCol && $orderDirn)
            {
                $query->order($db->escape($orderCol . ' ' . $orderDirn));
            }

            return $query;
	}

	/**
	 * Method to get an array of data items
	 *
	 * @return  mixed An array of data on success, false on failure.
	 */
	public function getItems()
	{
		$items = parent::getItems();
		
		foreach ($items as $item)
		{

			if (isset($item->plan_crop))
			{

				$values    = explode(',', $item->plan_crop);
				$textValue = array();

				foreach ($values as $value)
				{
					$db    = JFactory::getDbo();
					$query = $db->getQuery(true);
					$query
						->select('`#__agmanager_seed_3603915`.`crop_type`')
						->from($db->quoteName('#__agmanager_seed', '#__agmanager_seed_3603915'))
						->where($db->quoteName('#__agmanager_seed_3603915.crop_type') . ' = '. $db->quote($db->escape($value)));

					$db->setQuery($query);
					$results = $db->loadObject();

					if ($results)
					{
						$textValue[] = $results->crop_type;
					}
				}

				$item->plan_crop = !empty($textValue) ? implode(', ', $textValue) : $item->plan_crop;
			}


			if (isset($item->plan_fertilizer))
			{

				$values    = explode(',', $item->plan_fertilizer);
				$textValue = array();

				foreach ($values as $value)
				{
					$db    = JFactory::getDbo();
					$query = $db->getQuery(true);
					$query
						->select('`#__agmanager_fertilizer_3603916`.`fert_type`')
						->from($db->quoteName('#__agmanager_fertilizer', '#__agmanager_fertilizer_3603916'))
						->where($db->quoteName('#__agmanager_fertilizer_3603916.fert_type') . ' = '. $db->quote($db->escape($value)));

					$db->setQuery($query);
					$results = $db->loadObject();

					if ($results)
					{
						$textValue[] = $results->fert_type;
					}
				}

				$item->plan_fertilizer = !empty($textValue) ? implode(', ', $textValue) : $item->plan_fertilizer;
			}


			if (isset($item->plan_chemical))
			{

				$values    = explode(',', $item->plan_chemical);
				$textValue = array();

				foreach ($values as $value)
				{
					$db    = JFactory::getDbo();
					$query = $db->getQuery(true);
					$query
						->select('`#__agmanager_chemical_3603917`.`chem_type`')
						->from($db->quoteName('#__agmanager_chemical', '#__agmanager_chemical_3603917'))
						->where($db->quoteName('#__agmanager_chemical_3603917.chem_type') . ' = '. $db->quote($db->escape($value)));

					$db->setQuery($query);
					$results = $db->loadObject();

					if ($results)
					{
						$textValue[] = $results->chem_type;
					}
				}

				$item->plan_chemical = !empty($textValue) ? implode(', ', $textValue) : $item->plan_chemical;
			}


			if (isset($item->cost_seed))
			{

				$values    = explode(',', $item->cost_seed);
				$textValue = array();

				foreach ($values as $value)
				{
					$db    = JFactory::getDbo();
					$query = $db->getQuery(true);
					$query
						->select('`#__agmanager_seed_3603918`.`crop_per_acre`')
						->from($db->quoteName('#__agmanager_seed', '#__agmanager_seed_3603918'))
						->where($db->quoteName('#__agmanager_seed_3603918.crop_per_acre') . ' = '. $db->quote($db->escape($value)));

					$db->setQuery($query);
					$results = $db->loadObject();

					if ($results)
					{
						$textValue[] = $results->crop_per_acre;
					}
				}

				$item->cost_seed = !empty($textValue) ? implode(', ', $textValue) : $item->cost_seed;
			}


			if (isset($item->cost_fert))
			{

				$values    = explode(',', $item->cost_fert);
				$textValue = array();

				foreach ($values as $value)
				{
					$db    = JFactory::getDbo();
					$query = $db->getQuery(true);
					$query
						->select('`#__agmanager_fertilizer_3603919`.`fert_per_acre`')
						->from($db->quoteName('#__agmanager_fertilizer', '#__agmanager_fertilizer_3603919'))
						->where($db->quoteName('#__agmanager_fertilizer_3603919.fert_per_acre') . ' = '. $db->quote($db->escape($value)));

					$db->setQuery($query);
					$results = $db->loadObject();

					if ($results)
					{
						$textValue[] = $results->fert_per_acre;
					}
				}

				$item->cost_fert = !empty($textValue) ? implode(', ', $textValue) : $item->cost_fert;
			}


			if (isset($item->cost_chem))
			{

				$values    = explode(',', $item->cost_chem);
				$textValue = array();

				foreach ($values as $value)
				{
					$db    = JFactory::getDbo();
					$query = $db->getQuery(true);
					$query
						->select('`#__agmanager_chemical_3603920`.`chem_per_acre`')
						->from($db->quoteName('#__agmanager_chemical', '#__agmanager_chemical_3603920'))
						->where($db->quoteName('#__agmanager_chemical_3603920.chem_per_acre') . ' = '. $db->quote($db->escape($value)));

					$db->setQuery($query);
					$results = $db->loadObject();

					if ($results)
					{
						$textValue[] = $results->chem_per_acre;
					}
				}

				$item->cost_chem = !empty($textValue) ? implode(', ', $textValue) : $item->cost_chem;
			}

		}

		return $items;
	}

	/**
	 * Overrides the default function to check Date fields format, identified by
	 * "_dateformat" suffix, and erases the field if it's not correct.
	 *
	 * @return void
	 */
	protected function loadFormData()
	{
		$app              = Factory::getApplication();
		$filters          = $app->getUserState($this->context . '.filter', array());
		$error_dateformat = false;

		foreach ($filters as $key => $value)
		{
			if (strpos($key, '_dateformat') && !empty($value) && $this->isValidDate($value) == null)
			{
				$filters[$key]    = '';
				$error_dateformat = true;
			}
		}

		if ($error_dateformat)
		{
			$app->enqueueMessage(Text::_("COM_AGMANAGER_SEARCH_FILTER_DATE_FORMAT"), "warning");
			$app->setUserState($this->context . '.filter', $filters);
		}

		return parent::loadFormData();
	}

	/**
	 * Checks if a given date is valid and in a specified format (YYYY-MM-DD)
	 *
	 * @param   string  $date  Date to be checked
	 *
	 * @return bool
	 */
	private function isValidDate($date)
	{
		$date = str_replace('/', '-', $date);
		return (date_create($date)) ? Factory::getDate($date)->format("Y-m-d") : null;
	}
}
