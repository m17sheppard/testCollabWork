<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Agmanager
 * @author     Micah Windle <support@bankert.ca>
 * @copyright  2021 Bankert Marketing Inc. 
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Component\Router\RouterViewConfiguration;
use Joomla\CMS\Component\Router\RouterView;
use Joomla\CMS\Component\Router\Rules\StandardRules;
use Joomla\CMS\Component\Router\Rules\NomenuRules;
use Joomla\CMS\Component\Router\Rules\MenuRules;
use Joomla\CMS\Factory;
use Joomla\CMS\Categories\Categories;

/**
 * Class AgmanagerRouter
 *
 */
class AgmanagerRouter extends RouterView
{
	private $noIDs;
	public function __construct($app = null, $menu = null)
	{
		$params = JComponentHelper::getComponent('com_agmanager')->params;
		$this->noIDs = (bool) $params->get('sef_ids');
		
		$cropplans = new RouterViewConfiguration('cropplans');
		$this->registerView($cropplans);
			$cropplan = new RouterViewConfiguration('cropplan');
			$cropplan->setKey('id')->setParent($cropplans);
			$this->registerView($cropplan);
			$cropplanform = new RouterViewConfiguration('cropplanform');
			$cropplanform->setKey('id');
			$this->registerView($cropplanform);$livestocks = new RouterViewConfiguration('livestocks');
		$this->registerView($livestocks);
			$livestock = new RouterViewConfiguration('livestock');
			$livestock->setKey('id')->setParent($livestocks);
			$this->registerView($livestock);
			$livestockform = new RouterViewConfiguration('livestockform');
			$livestockform->setKey('id');
			$this->registerView($livestockform);$ownedlands = new RouterViewConfiguration('ownedlands');
		$this->registerView($ownedlands);
			$ownedland = new RouterViewConfiguration('ownedland');
			$ownedland->setKey('id')->setParent($ownedlands);
			$this->registerView($ownedland);
			$ownedlandform = new RouterViewConfiguration('ownedlandform');
			$ownedlandform->setKey('id');
			$this->registerView($ownedlandform);$leasedlands = new RouterViewConfiguration('leasedlands');
		$this->registerView($leasedlands);
			$leasedland = new RouterViewConfiguration('leasedland');
			$leasedland->setKey('id')->setParent($leasedlands);
			$this->registerView($leasedland);
			$leasedlandform = new RouterViewConfiguration('leasedlandform');
			$leasedlandform->setKey('id');
			$this->registerView($leasedlandform);$buildingsquotas = new RouterViewConfiguration('buildingsquotas');
		$this->registerView($buildingsquotas);
			$buildingquota = new RouterViewConfiguration('buildingquota');
			$buildingquota->setKey('id')->setParent($buildingsquotas);
			$this->registerView($buildingquota);
			$buildingquotaform = new RouterViewConfiguration('buildingquotaform');
			$buildingquotaform->setKey('id');
			$this->registerView($buildingquotaform);$bins = new RouterViewConfiguration('bins');
		$this->registerView($bins);
			$bin = new RouterViewConfiguration('bin');
			$bin->setKey('id')->setParent($bins);
			$this->registerView($bin);
			$binform = new RouterViewConfiguration('binform');
			$binform->setKey('id');
			$this->registerView($binform);$machineryequipments = new RouterViewConfiguration('machineryequipments');
		$this->registerView($machineryequipments);
			$machineryequipment = new RouterViewConfiguration('machineryequipment');
			$machineryequipment->setKey('id')->setParent($machineryequipments);
			$this->registerView($machineryequipment);
			$machineryequipmentform = new RouterViewConfiguration('machineryequipmentform');
			$machineryequipmentform->setKey('id');
			$this->registerView($machineryequipmentform);$debts = new RouterViewConfiguration('debts');
		$this->registerView($debts);
			$debt = new RouterViewConfiguration('debt');
			$debt->setKey('id')->setParent($debts);
			$this->registerView($debt);
			$debtform = new RouterViewConfiguration('debtform');
			$debtform->setKey('id');
			$this->registerView($debtform);$financesinflows = new RouterViewConfiguration('financesinflows');
		$this->registerView($financesinflows);
			$financesinflow = new RouterViewConfiguration('financesinflow');
			$financesinflow->setKey('id')->setParent($financesinflows);
			$this->registerView($financesinflow);
			$financesinflowform = new RouterViewConfiguration('financesinflowform');
			$financesinflowform->setKey('id');
			$this->registerView($financesinflowform);$financeoutflows = new RouterViewConfiguration('financeoutflows');
		$this->registerView($financeoutflows);
			$financesoutflow = new RouterViewConfiguration('financesoutflow');
			$financesoutflow->setKey('id')->setParent($financeoutflows);
			$this->registerView($financesoutflow);
			$financesoutflowform = new RouterViewConfiguration('financesoutflowform');
			$financesoutflowform->setKey('id');
			$this->registerView($financesoutflowform);$financesassets = new RouterViewConfiguration('financesassets');
		$this->registerView($financesassets);
			$financesasset = new RouterViewConfiguration('financesasset');
			$financesasset->setKey('id')->setParent($financesassets);
			$this->registerView($financesasset);
			$financesassetform = new RouterViewConfiguration('financesassetform');
			$financesassetform->setKey('id');
			$this->registerView($financesassetform);$paymentprojections = new RouterViewConfiguration('paymentprojections');
		$this->registerView($paymentprojections);
			$paymentsprojection = new RouterViewConfiguration('paymentsprojection');
			$paymentsprojection->setKey('id')->setParent($paymentprojections);
			$this->registerView($paymentsprojection);
			$paymentsprojectionform = new RouterViewConfiguration('paymentsprojectionform');
			$paymentsprojectionform->setKey('id');
			$this->registerView($paymentsprojectionform);

		parent::__construct($app, $menu);

		$this->attachRule(new MenuRules($this));

		if ($params->get('sef_advanced', 0))
		{
			$this->attachRule(new StandardRules($this));
			$this->attachRule(new NomenuRules($this));
		}
		else
		{
			JLoader::register('AgmanagerRulesLegacy', __DIR__ . '/helpers/legacyrouter.php');
			JLoader::register('AgmanagerHelpersAgmanager', __DIR__ . '/helpers/agmanager.php');
			$this->attachRule(new AgmanagerRulesLegacy($this));
		}
	}


	
		/**
		 * Method to get the segment(s) for an cropplan
		 *
		 * @param   string  $id     ID of the cropplan to retrieve the segments for
		 * @param   array   $query  The request that is built right now
		 *
		 * @return  array|string  The segments of this item
		 */
		public function getCropplanSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			 * Method to get the segment(s) for an cropplanform
			 *
			 * @param   string  $id     ID of the cropplanform to retrieve the segments for
			 * @param   array   $query  The request that is built right now
			 *
			 * @return  array|string  The segments of this item
			 */
			public function getCropplanformSegment($id, $query)
			{
				return $this->getCropplanSegment($id, $query);
			}
		/**
		 * Method to get the segment(s) for an livestock
		 *
		 * @param   string  $id     ID of the livestock to retrieve the segments for
		 * @param   array   $query  The request that is built right now
		 *
		 * @return  array|string  The segments of this item
		 */
		public function getLivestockSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			 * Method to get the segment(s) for an livestockform
			 *
			 * @param   string  $id     ID of the livestockform to retrieve the segments for
			 * @param   array   $query  The request that is built right now
			 *
			 * @return  array|string  The segments of this item
			 */
			public function getLivestockformSegment($id, $query)
			{
				return $this->getLivestockSegment($id, $query);
			}
		/**
		 * Method to get the segment(s) for an ownedland
		 *
		 * @param   string  $id     ID of the ownedland to retrieve the segments for
		 * @param   array   $query  The request that is built right now
		 *
		 * @return  array|string  The segments of this item
		 */
		public function getOwnedlandSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			 * Method to get the segment(s) for an ownedlandform
			 *
			 * @param   string  $id     ID of the ownedlandform to retrieve the segments for
			 * @param   array   $query  The request that is built right now
			 *
			 * @return  array|string  The segments of this item
			 */
			public function getOwnedlandformSegment($id, $query)
			{
				return $this->getOwnedlandSegment($id, $query);
			}
		/**
		 * Method to get the segment(s) for an leasedland
		 *
		 * @param   string  $id     ID of the leasedland to retrieve the segments for
		 * @param   array   $query  The request that is built right now
		 *
		 * @return  array|string  The segments of this item
		 */
		public function getLeasedlandSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			 * Method to get the segment(s) for an leasedlandform
			 *
			 * @param   string  $id     ID of the leasedlandform to retrieve the segments for
			 * @param   array   $query  The request that is built right now
			 *
			 * @return  array|string  The segments of this item
			 */
			public function getLeasedlandformSegment($id, $query)
			{
				return $this->getLeasedlandSegment($id, $query);
			}
		/**
		 * Method to get the segment(s) for an buildingquota
		 *
		 * @param   string  $id     ID of the buildingquota to retrieve the segments for
		 * @param   array   $query  The request that is built right now
		 *
		 * @return  array|string  The segments of this item
		 */
		public function getBuildingquotaSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			 * Method to get the segment(s) for an buildingquotaform
			 *
			 * @param   string  $id     ID of the buildingquotaform to retrieve the segments for
			 * @param   array   $query  The request that is built right now
			 *
			 * @return  array|string  The segments of this item
			 */
			public function getBuildingquotaformSegment($id, $query)
			{
				return $this->getBuildingquotaSegment($id, $query);
			}
		/**
		 * Method to get the segment(s) for an bin
		 *
		 * @param   string  $id     ID of the bin to retrieve the segments for
		 * @param   array   $query  The request that is built right now
		 *
		 * @return  array|string  The segments of this item
		 */
		public function getBinSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			 * Method to get the segment(s) for an binform
			 *
			 * @param   string  $id     ID of the binform to retrieve the segments for
			 * @param   array   $query  The request that is built right now
			 *
			 * @return  array|string  The segments of this item
			 */
			public function getBinformSegment($id, $query)
			{
				return $this->getBinSegment($id, $query);
			}
		/**
		 * Method to get the segment(s) for an machineryequipment
		 *
		 * @param   string  $id     ID of the machineryequipment to retrieve the segments for
		 * @param   array   $query  The request that is built right now
		 *
		 * @return  array|string  The segments of this item
		 */
		public function getMachineryequipmentSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			 * Method to get the segment(s) for an machineryequipmentform
			 *
			 * @param   string  $id     ID of the machineryequipmentform to retrieve the segments for
			 * @param   array   $query  The request that is built right now
			 *
			 * @return  array|string  The segments of this item
			 */
			public function getMachineryequipmentformSegment($id, $query)
			{
				return $this->getMachineryequipmentSegment($id, $query);
			}
		/**
		 * Method to get the segment(s) for an debt
		 *
		 * @param   string  $id     ID of the debt to retrieve the segments for
		 * @param   array   $query  The request that is built right now
		 *
		 * @return  array|string  The segments of this item
		 */
		public function getDebtSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			 * Method to get the segment(s) for an debtform
			 *
			 * @param   string  $id     ID of the debtform to retrieve the segments for
			 * @param   array   $query  The request that is built right now
			 *
			 * @return  array|string  The segments of this item
			 */
			public function getDebtformSegment($id, $query)
			{
				return $this->getDebtSegment($id, $query);
			}
		/**
		 * Method to get the segment(s) for an financesinflow
		 *
		 * @param   string  $id     ID of the financesinflow to retrieve the segments for
		 * @param   array   $query  The request that is built right now
		 *
		 * @return  array|string  The segments of this item
		 */
		public function getFinancesinflowSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			 * Method to get the segment(s) for an financesinflowform
			 *
			 * @param   string  $id     ID of the financesinflowform to retrieve the segments for
			 * @param   array   $query  The request that is built right now
			 *
			 * @return  array|string  The segments of this item
			 */
			public function getFinancesinflowformSegment($id, $query)
			{
				return $this->getFinancesinflowSegment($id, $query);
			}
		/**
		 * Method to get the segment(s) for an financesoutflow
		 *
		 * @param   string  $id     ID of the financesoutflow to retrieve the segments for
		 * @param   array   $query  The request that is built right now
		 *
		 * @return  array|string  The segments of this item
		 */
		public function getFinancesoutflowSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			 * Method to get the segment(s) for an financesoutflowform
			 *
			 * @param   string  $id     ID of the financesoutflowform to retrieve the segments for
			 * @param   array   $query  The request that is built right now
			 *
			 * @return  array|string  The segments of this item
			 */
			public function getFinancesoutflowformSegment($id, $query)
			{
				return $this->getFinancesoutflowSegment($id, $query);
			}
		/**
		 * Method to get the segment(s) for an financesasset
		 *
		 * @param   string  $id     ID of the financesasset to retrieve the segments for
		 * @param   array   $query  The request that is built right now
		 *
		 * @return  array|string  The segments of this item
		 */
		public function getFinancesassetSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			 * Method to get the segment(s) for an financesassetform
			 *
			 * @param   string  $id     ID of the financesassetform to retrieve the segments for
			 * @param   array   $query  The request that is built right now
			 *
			 * @return  array|string  The segments of this item
			 */
			public function getFinancesassetformSegment($id, $query)
			{
				return $this->getFinancesassetSegment($id, $query);
			}
		/**
		 * Method to get the segment(s) for an paymentsprojection
		 *
		 * @param   string  $id     ID of the paymentsprojection to retrieve the segments for
		 * @param   array   $query  The request that is built right now
		 *
		 * @return  array|string  The segments of this item
		 */
		public function getPaymentsprojectionSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			 * Method to get the segment(s) for an paymentsprojectionform
			 *
			 * @param   string  $id     ID of the paymentsprojectionform to retrieve the segments for
			 * @param   array   $query  The request that is built right now
			 *
			 * @return  array|string  The segments of this item
			 */
			public function getPaymentsprojectionformSegment($id, $query)
			{
				return $this->getPaymentsprojectionSegment($id, $query);
			}

	
		/**
		 * Method to get the segment(s) for an cropplan
		 *
		 * @param   string  $segment  Segment of the cropplan to retrieve the ID for
		 * @param   array   $query    The request that is parsed right now
		 *
		 * @return  mixed   The id of this item or false
		 */
		public function getCropplanId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			 * Method to get the segment(s) for an cropplanform
			 *
			 * @param   string  $segment  Segment of the cropplanform to retrieve the ID for
			 * @param   array   $query    The request that is parsed right now
			 *
			 * @return  mixed   The id of this item or false
			 */
			public function getCropplanformId($segment, $query)
			{
				return $this->getCropplanId($segment, $query);
			}
		/**
		 * Method to get the segment(s) for an livestock
		 *
		 * @param   string  $segment  Segment of the livestock to retrieve the ID for
		 * @param   array   $query    The request that is parsed right now
		 *
		 * @return  mixed   The id of this item or false
		 */
		public function getLivestockId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			 * Method to get the segment(s) for an livestockform
			 *
			 * @param   string  $segment  Segment of the livestockform to retrieve the ID for
			 * @param   array   $query    The request that is parsed right now
			 *
			 * @return  mixed   The id of this item or false
			 */
			public function getLivestockformId($segment, $query)
			{
				return $this->getLivestockId($segment, $query);
			}
		/**
		 * Method to get the segment(s) for an ownedland
		 *
		 * @param   string  $segment  Segment of the ownedland to retrieve the ID for
		 * @param   array   $query    The request that is parsed right now
		 *
		 * @return  mixed   The id of this item or false
		 */
		public function getOwnedlandId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			 * Method to get the segment(s) for an ownedlandform
			 *
			 * @param   string  $segment  Segment of the ownedlandform to retrieve the ID for
			 * @param   array   $query    The request that is parsed right now
			 *
			 * @return  mixed   The id of this item or false
			 */
			public function getOwnedlandformId($segment, $query)
			{
				return $this->getOwnedlandId($segment, $query);
			}
		/**
		 * Method to get the segment(s) for an leasedland
		 *
		 * @param   string  $segment  Segment of the leasedland to retrieve the ID for
		 * @param   array   $query    The request that is parsed right now
		 *
		 * @return  mixed   The id of this item or false
		 */
		public function getLeasedlandId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			 * Method to get the segment(s) for an leasedlandform
			 *
			 * @param   string  $segment  Segment of the leasedlandform to retrieve the ID for
			 * @param   array   $query    The request that is parsed right now
			 *
			 * @return  mixed   The id of this item or false
			 */
			public function getLeasedlandformId($segment, $query)
			{
				return $this->getLeasedlandId($segment, $query);
			}
		/**
		 * Method to get the segment(s) for an buildingquota
		 *
		 * @param   string  $segment  Segment of the buildingquota to retrieve the ID for
		 * @param   array   $query    The request that is parsed right now
		 *
		 * @return  mixed   The id of this item or false
		 */
		public function getBuildingquotaId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			 * Method to get the segment(s) for an buildingquotaform
			 *
			 * @param   string  $segment  Segment of the buildingquotaform to retrieve the ID for
			 * @param   array   $query    The request that is parsed right now
			 *
			 * @return  mixed   The id of this item or false
			 */
			public function getBuildingquotaformId($segment, $query)
			{
				return $this->getBuildingquotaId($segment, $query);
			}
		/**
		 * Method to get the segment(s) for an bin
		 *
		 * @param   string  $segment  Segment of the bin to retrieve the ID for
		 * @param   array   $query    The request that is parsed right now
		 *
		 * @return  mixed   The id of this item or false
		 */
		public function getBinId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			 * Method to get the segment(s) for an binform
			 *
			 * @param   string  $segment  Segment of the binform to retrieve the ID for
			 * @param   array   $query    The request that is parsed right now
			 *
			 * @return  mixed   The id of this item or false
			 */
			public function getBinformId($segment, $query)
			{
				return $this->getBinId($segment, $query);
			}
		/**
		 * Method to get the segment(s) for an machineryequipment
		 *
		 * @param   string  $segment  Segment of the machineryequipment to retrieve the ID for
		 * @param   array   $query    The request that is parsed right now
		 *
		 * @return  mixed   The id of this item or false
		 */
		public function getMachineryequipmentId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			 * Method to get the segment(s) for an machineryequipmentform
			 *
			 * @param   string  $segment  Segment of the machineryequipmentform to retrieve the ID for
			 * @param   array   $query    The request that is parsed right now
			 *
			 * @return  mixed   The id of this item or false
			 */
			public function getMachineryequipmentformId($segment, $query)
			{
				return $this->getMachineryequipmentId($segment, $query);
			}
		/**
		 * Method to get the segment(s) for an debt
		 *
		 * @param   string  $segment  Segment of the debt to retrieve the ID for
		 * @param   array   $query    The request that is parsed right now
		 *
		 * @return  mixed   The id of this item or false
		 */
		public function getDebtId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			 * Method to get the segment(s) for an debtform
			 *
			 * @param   string  $segment  Segment of the debtform to retrieve the ID for
			 * @param   array   $query    The request that is parsed right now
			 *
			 * @return  mixed   The id of this item or false
			 */
			public function getDebtformId($segment, $query)
			{
				return $this->getDebtId($segment, $query);
			}
		/**
		 * Method to get the segment(s) for an financesinflow
		 *
		 * @param   string  $segment  Segment of the financesinflow to retrieve the ID for
		 * @param   array   $query    The request that is parsed right now
		 *
		 * @return  mixed   The id of this item or false
		 */
		public function getFinancesinflowId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			 * Method to get the segment(s) for an financesinflowform
			 *
			 * @param   string  $segment  Segment of the financesinflowform to retrieve the ID for
			 * @param   array   $query    The request that is parsed right now
			 *
			 * @return  mixed   The id of this item or false
			 */
			public function getFinancesinflowformId($segment, $query)
			{
				return $this->getFinancesinflowId($segment, $query);
			}
		/**
		 * Method to get the segment(s) for an financesoutflow
		 *
		 * @param   string  $segment  Segment of the financesoutflow to retrieve the ID for
		 * @param   array   $query    The request that is parsed right now
		 *
		 * @return  mixed   The id of this item or false
		 */
		public function getFinancesoutflowId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			 * Method to get the segment(s) for an financesoutflowform
			 *
			 * @param   string  $segment  Segment of the financesoutflowform to retrieve the ID for
			 * @param   array   $query    The request that is parsed right now
			 *
			 * @return  mixed   The id of this item or false
			 */
			public function getFinancesoutflowformId($segment, $query)
			{
				return $this->getFinancesoutflowId($segment, $query);
			}
		/**
		 * Method to get the segment(s) for an financesasset
		 *
		 * @param   string  $segment  Segment of the financesasset to retrieve the ID for
		 * @param   array   $query    The request that is parsed right now
		 *
		 * @return  mixed   The id of this item or false
		 */
		public function getFinancesassetId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			 * Method to get the segment(s) for an financesassetform
			 *
			 * @param   string  $segment  Segment of the financesassetform to retrieve the ID for
			 * @param   array   $query    The request that is parsed right now
			 *
			 * @return  mixed   The id of this item or false
			 */
			public function getFinancesassetformId($segment, $query)
			{
				return $this->getFinancesassetId($segment, $query);
			}
		/**
		 * Method to get the segment(s) for an paymentsprojection
		 *
		 * @param   string  $segment  Segment of the paymentsprojection to retrieve the ID for
		 * @param   array   $query    The request that is parsed right now
		 *
		 * @return  mixed   The id of this item or false
		 */
		public function getPaymentsprojectionId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			 * Method to get the segment(s) for an paymentsprojectionform
			 *
			 * @param   string  $segment  Segment of the paymentsprojectionform to retrieve the ID for
			 * @param   array   $query    The request that is parsed right now
			 *
			 * @return  mixed   The id of this item or false
			 */
			public function getPaymentsprojectionformId($segment, $query)
			{
				return $this->getPaymentsprojectionId($segment, $query);
			}
}
