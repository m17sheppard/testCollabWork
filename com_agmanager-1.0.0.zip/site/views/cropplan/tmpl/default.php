<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Agmanager
 * @author     Micah Windle <support@bankert.ca>
 * @copyright  2021 Bankert Marketing Inc. 
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

$canEdit = JFactory::getUser()->authorise('core.edit', 'com_agmanager');

if (!$canEdit && JFactory::getUser()->authorise('core.edit.own', 'com_agmanager'))
{
	$canEdit = JFactory::getUser()->id == $this->item->created_by;
}
?>

<div class="item_fields">

	<table class="table">
		

		<tr>
			<th><?php echo JText::_('COM_AGMANAGER_FORM_LBL_CROPPLAN_LOCATION_LEGAL'); ?></th>
			<td><?php echo $this->item->location_legal; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_AGMANAGER_FORM_LBL_CROPPLAN_LOCATION_ACREAGE'); ?></th>
			<td><?php echo $this->item->location_acreage; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_AGMANAGER_FORM_LBL_CROPPLAN_PLAN_CROP'); ?></th>
			<td><?php echo $this->item->plan_crop; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_AGMANAGER_FORM_LBL_CROPPLAN_PLAN_FERTILIZER'); ?></th>
			<td><?php echo $this->item->plan_fertilizer; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_AGMANAGER_FORM_LBL_CROPPLAN_PLAN_CHEMICAL'); ?></th>
			<td><?php echo $this->item->plan_chemical; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_AGMANAGER_FORM_LBL_CROPPLAN_COST_SEED'); ?></th>
			<td><?php echo $this->item->cost_seed; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_AGMANAGER_FORM_LBL_CROPPLAN_COST_FERT'); ?></th>
			<td><?php echo $this->item->cost_fert; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_AGMANAGER_FORM_LBL_CROPPLAN_COST_CHEM'); ?></th>
			<td><?php if( $this->item->plan_chemical == "" ) echo $this->item->cost_chem; ?></td>
		</tr>

	</table>

</div>

<?php if($canEdit && $this->item->checked_out == 0): ?>

	<a class="btn" href="<?php echo JRoute::_('index.php?option=com_agmanager&task=cropplan.edit&id='.$this->item->id); ?>"><?php echo JText::_("COM_AGMANAGER_EDIT_ITEM"); ?></a>

<?php endif; ?>

<?php if (JFactory::getUser()->authorise('core.delete','com_agmanager.cropplan.'.$this->item->id)) : ?>

	<a class="btn btn-danger" href="#deleteModal" role="button" data-toggle="modal">
		<?php echo JText::_("COM_AGMANAGER_DELETE_ITEM"); ?>
	</a>

	<div id="deleteModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="deleteModal" aria-hidden="true">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			<h3><?php echo JText::_('COM_AGMANAGER_DELETE_ITEM'); ?></h3>
		</div>
		<div class="modal-body">
			<p><?php echo JText::sprintf('COM_AGMANAGER_DELETE_CONFIRM', $this->item->id); ?></p>
		</div>
		<div class="modal-footer">
			<button class="btn" data-dismiss="modal">Close</button>
			<a href="<?php echo JRoute::_('index.php?option=com_agmanager&task=cropplan.remove&id=' . $this->item->id, false, 2); ?>" class="btn btn-danger">
				<?php echo JText::_('COM_AGMANAGER_DELETE_ITEM'); ?>
			</a>
		</div>
	</div>

<?php endif; ?>