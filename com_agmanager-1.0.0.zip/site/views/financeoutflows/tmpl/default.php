<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Agmanager
 * @author     Micah Windle <support@bankert.ca>
 * @copyright  2021 Bankert Marketing Inc. 
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Layout\LayoutHelper;

HTMLHelper::addIncludePath(JPATH_COMPONENT . '/helpers/html');
HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');
HTMLHelper::_('formbehavior.chosen', 'select');

$user       = Factory::getUser();
$userId     = $user->get('id');
$listOrder  = $this->state->get('list.ordering');
$listDirn   = $this->state->get('list.direction');
$canCreate  = $user->authorise('core.create', 'com_agmanager') && file_exists(JPATH_COMPONENT . DIRECTORY_SEPARATOR . 'models' . DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR . 'financesoutflowform.xml');
$canEdit    = $user->authorise('core.edit', 'com_agmanager') && file_exists(JPATH_COMPONENT . DIRECTORY_SEPARATOR . 'models' . DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR . 'financesoutflowform.xml');
$canCheckin = $user->authorise('core.manage', 'com_agmanager');
$canChange  = $user->authorise('core.edit.state', 'com_agmanager');
$canDelete  = $user->authorise('core.delete', 'com_agmanager');

// Import CSS
$document = Factory::getDocument();
$document->addStyleSheet(Uri::root() . 'media/com_agmanager/css/list.css');
?>

<form action="<?php echo htmlspecialchars(Uri::getInstance()->toString()); ?>" method="post"
      name="adminForm" id="adminForm">

	
        <div class="table-responsive">
	<table class="table table-striped" id="financesoutflowList">
		<thead>
		<tr>
			<?php if (isset($this->items[0]->state)): ?>
				
			<?php endif; ?>

							<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_SEED_PURCHASES', 'a.seed_purchases', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_SEED_CLEANING', 'a.seed_cleaning', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_SEED_TREATMENT', 'a.seed_treatment', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_FERTILIZER', 'a.fertilizer', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_CHEMICALS', 'a.chemicals', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_HAILCROP_INSURANCE', 'a.hailcrop_insurance', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_OTHER_CROP_EXPENSES', 'a.other_crop_expenses', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_GRAINHAY_PURCHASES', 'a.grainhay_purchases', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_COMMERCIAL_FEED_PURCHASES', 'a.commercial_feed_purchases', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_SALT', 'a.salt', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_MINERALS', 'a.minerals', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_VITAMINS', 'a.vitamins', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_PASTURE_RENT', 'a.pasture_rent', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_CONTAINERS_TWINE', 'a.containers_twine', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_BREEDING_FEES', 'a.breeding_fees', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_VET_FEES', 'a.vet_fees', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_DRUGS', 'a.drugs', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_BREEDING_STOCK_PURCHASES', 'a.breeding_stock_purchases', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_MARKET_STOCK_PURCHASES', 'a.market_stock_purchases', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_MARKETING_CHARGES', 'a.marketing_charges', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_OTHER_LIVESTOCK_EXPENSES', 'a.other_livestock_expenses', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_PROPERTY_TAX', 'a.property_tax', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_CAPITAL_LAND_PURCHASES', 'a.capital_land_purchases', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_NEW_LEASE_PAYMENTS', 'a.new_lease_payments', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_EXISTING_LEASE_PAYMENTS', 'a.existing_lease_payments', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_ANNUAL_CASH_RENT_LEASED_LAND', 'a.annual_cash_rent_leased_land', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_FUEL', 'a.fuel', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_OIL', 'a.oil', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_GREASE', 'a.grease', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_EQUIPMENT_REPAIR', 'a.equipment_repair', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_SHOP_SUPPLIES', 'a.shop_supplies', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_SMALL_TOOLS', 'a.small_tools', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_BUILDING_INSURANCE', 'a.building_insurance', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_BUILDING_REPAIRS', 'a.building_repairs', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_FENCE_REPAIRS', 'a.fence_repairs', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_VEHICLE_REGISTRATIONINSURANCE', 'a.vehicle_registrationinsurance', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_CAPITAL_MACHINESBUILDINGS_PURCHASES', 'a.capital_machinesbuildings_purchases', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_PROFESSIONAL_FEES', 'a.professional_fees', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_CUSTOM_WORK', 'a.custom_work', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_HYDROTELEPHONE', 'a.hydrotelephone', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_HIRED_LABOUR', 'a.hired_labour', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_OFFICE_EXPENSES', 'a.office_expenses', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_OTHER_ASSETINVESTMENT_PURCHASES', 'a.other_assetinvestment_purchases', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_OTHER_FARM_EXPENSES', 'a.other_farm_expenses', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_LIVING_EXPENSES', 'a.living_expenses', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_INCOME_TAX', 'a.income_tax', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_LIFE_INSURANCE', 'a.life_insurance', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_CASH_WITHDRAWALS', 'a.cash_withdrawals', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_ACCOUNTS_PAYABLE', 'a.accounts_payable', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_REPAYMENT_CASH_ADVANCE_PRINCIPAL', 'a.repayment_cash_advance_principal', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_REPAYMENT_CASH_ADVANCE_INTEREST', 'a.repayment_cash_advance_interest', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_ARREARS_PAYMENT', 'a.arrears_payment', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_TERM_LOAN_PAYMENT_PRINCIPAL', 'a.term_loan_payment_principal', $listDirn, $listOrder); ?>
				</th>
				<th class=''>
				<?php echo JHtml::_('grid.sort',  'COM_AGMANAGER_FINANCEOUTFLOWS_TERM_LOAN_PAYMENT_INTEREST', 'a.term_loan_payment_interest', $listDirn, $listOrder); ?>
				</th>


							<?php if ($canEdit || $canDelete): ?>
					<th class="center">
				<?php echo JText::_('COM_AGMANAGER_FINANCEOUTFLOWS_ACTIONS'); ?>
				</th>
				<?php endif; ?>

		</tr>
		</thead>
		<tfoot>
		<tr>
			<td colspan="<?php echo isset($this->items[0]) ? count(get_object_vars($this->items[0])) : 10; ?>">
				<?php echo $this->pagination->getListFooter(); ?>
			</td>
		</tr>
		</tfoot>
		<tbody>
		<?php foreach ($this->items as $i => $item) : ?>
			<?php $canEdit = $user->authorise('core.edit', 'com_agmanager'); ?>

							<?php if (!$canEdit && $user->authorise('core.edit.own', 'com_agmanager')): ?>
					<?php $canEdit = JFactory::getUser()->id == $item->created_by; ?>
				<?php endif; ?>

			<tr class="row<?php echo $i % 2; ?>">

				<?php if (isset($this->items[0]->state)) : ?>
					<?php $class = ($canChange) ? 'active' : 'disabled'; ?>
					
				<?php endif; ?>

								<td>

					<?php echo $item->seed_purchases; ?>
				</td>
				<td>

					<?php echo $item->seed_cleaning; ?>
				</td>
				<td>

					<?php echo $item->seed_treatment; ?>
				</td>
				<td>

					<?php echo $item->fertilizer; ?>
				</td>
				<td>

					<?php echo $item->chemicals; ?>
				</td>
				<td>

					<?php echo $item->hailcrop_insurance; ?>
				</td>
				<td>

					<?php echo $item->other_crop_expenses; ?>
				</td>
				<td>

					<?php echo $item->grainhay_purchases; ?>
				</td>
				<td>

					<?php echo $item->commercial_feed_purchases; ?>
				</td>
				<td>

					<?php echo $item->salt; ?>
				</td>
				<td>

					<?php echo $item->minerals; ?>
				</td>
				<td>

					<?php echo $item->vitamins; ?>
				</td>
				<td>

					<?php echo $item->pasture_rent; ?>
				</td>
				<td>

					<?php echo $item->containers_twine; ?>
				</td>
				<td>

					<?php echo $item->breeding_fees; ?>
				</td>
				<td>

					<?php echo $item->vet_fees; ?>
				</td>
				<td>

					<?php echo $item->drugs; ?>
				</td>
				<td>

					<?php echo $item->breeding_stock_purchases; ?>
				</td>
				<td>

					<?php echo $item->market_stock_purchases; ?>
				</td>
				<td>

					<?php echo $item->marketing_charges; ?>
				</td>
				<td>

					<?php echo $item->other_livestock_expenses; ?>
				</td>
				<td>

					<?php echo $item->property_tax; ?>
				</td>
				<td>

					<?php echo $item->capital_land_purchases; ?>
				</td>
				<td>

					<?php echo $item->new_lease_payments; ?>
				</td>
				<td>

					<?php echo $item->existing_lease_payments; ?>
				</td>
				<td>

					<?php echo $item->annual_cash_rent_leased_land; ?>
				</td>
				<td>

					<?php echo $item->fuel; ?>
				</td>
				<td>

					<?php echo $item->oil; ?>
				</td>
				<td>

					<?php echo $item->grease; ?>
				</td>
				<td>

					<?php echo $item->equipment_repair; ?>
				</td>
				<td>

					<?php echo $item->shop_supplies; ?>
				</td>
				<td>

					<?php echo $item->small_tools; ?>
				</td>
				<td>

					<?php echo $item->building_insurance; ?>
				</td>
				<td>

					<?php echo $item->building_repairs; ?>
				</td>
				<td>

					<?php echo $item->fence_repairs; ?>
				</td>
				<td>

					<?php echo $item->vehicle_registrationinsurance; ?>
				</td>
				<td>

					<?php echo $item->capital_machinesbuildings_purchases; ?>
				</td>
				<td>

					<?php echo $item->professional_fees; ?>
				</td>
				<td>

					<?php echo $item->custom_work; ?>
				</td>
				<td>

					<?php echo $item->hydrotelephone; ?>
				</td>
				<td>

					<?php echo $item->hired_labour; ?>
				</td>
				<td>

					<?php echo $item->office_expenses; ?>
				</td>
				<td>

					<?php echo $item->other_assetinvestment_purchases; ?>
				</td>
				<td>

					<?php echo $item->other_farm_expenses; ?>
				</td>
				<td>

					<?php echo $item->living_expenses; ?>
				</td>
				<td>

					<?php echo $item->income_tax; ?>
				</td>
				<td>

					<?php echo $item->life_insurance; ?>
				</td>
				<td>

					<?php echo $item->cash_withdrawals; ?>
				</td>
				<td>

					<?php echo $item->accounts_payable; ?>
				</td>
				<td>

					<?php echo $item->repayment_cash_advance_principal; ?>
				</td>
				<td>

					<?php echo $item->repayment_cash_advance_interest; ?>
				</td>
				<td>

					<?php echo $item->arrears_payment; ?>
				</td>
				<td>

					<?php echo $item->term_loan_payment_principal; ?>
				</td>
				<td>

					<?php echo $item->term_loan_payment_interest; ?>
				</td>


								<?php if ($canEdit || $canDelete): ?>
					<td class="center">
						<?php if ($canEdit): ?>
							<a href="<?php echo JRoute::_('index.php?option=com_agmanager&task=financesoutflow.edit&id=' . $item->id, false, 2); ?>" class="btn btn-mini" type="button"><i class="icon-edit" ></i></a>
						<?php endif; ?>
						<?php if ($canDelete): ?>
							<a href="<?php echo JRoute::_('index.php?option=com_agmanager&task=financesoutflowform.remove&id=' . $item->id, false, 2); ?>" class="btn btn-mini delete-button" type="button"><i class="icon-trash" ></i></a>
						<?php endif; ?>
					</td>
				<?php endif; ?>

			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
        </div>
	<?php if ($canCreate) : ?>
		<a href="<?php echo Route::_('index.php?option=com_agmanager&task=financesoutflowform.edit&id=0', false, 0); ?>"
		   class="btn btn-success btn-small"><i
				class="icon-plus"></i>
			<?php echo Text::_('COM_AGMANAGER_ADD_ITEM'); ?></a>
	<?php endif; ?>

	<input type="hidden" name="task" value=""/>
	<input type="hidden" name="boxchecked" value="0"/>
	<input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>"/>
	<input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>"/>
	<?php echo HTMLHelper::_('form.token'); ?>
</form>

<?php if($canDelete) : ?>
<script type="text/javascript">

	jQuery(document).ready(function () {
		jQuery('.delete-button').click(deleteItem);
	});

	function deleteItem() {

		if (!confirm("<?php echo Text::_('COM_AGMANAGER_DELETE_MESSAGE'); ?>")) {
			return false;
		}
	}
</script>
<?php endif; ?>
